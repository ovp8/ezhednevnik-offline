# log_capture.py
"""Перехват консольного вывода сервера в кольцевой буфер + фильтр спама.

Зачем: в дашборде Render логи неудобно читать — health-проверки /api/health
шли каждые 5 секунд (десятки тысяч строк мусора в день), истории нет,
искать по ней нельзя. Этот модуль решает обе проблемы:

  1. Подавляет access-логи по /api/health (их печатают Render-мониторы
     и keep-alive cron-job.org — реальной пользы в логе от них нет).
  2. Сохраняет последние CAPACITY строк консоли (stdout + stderr) в память.
     В буфер попадает ровно то, что видно в консоли: print'ы, логи uvicorn,
     flet_web, трейсбеки.
  3. Содержимое буфера отдаётся через /logs и /api/logs (iphone_server.py).

Только стандартная библиотека. Вызывается как можно раньше:
    import log_capture; log_capture.setup()
"""
import io
import logging
import os
import re
import sys
import threading
import time

# ---- параметры -----------------------------------------------------------

CAPACITY = 2000            # сколько последних строк хранить в буфере
# Путь, access-логи которых не пишем вовсе: health-проверки хостинга
# (каждые ~5 с) и опросы собственным просмотрщиком /logs (каждые 3 с).
HEALTH_PATH = "/api/health"
QUIET_PATHS = ("/api/health", "/api/logs")

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")

_lock = threading.Lock()
_lines = []                # список строк (усекается до CAPACITY)
_dropped_health = 0        # сколько health-строк подавлено фильтром
_started_at = time.time()
_installed = False


# ---- внутреннее ----------------------------------------------------------

class _HealthFilter(logging.Filter):
    """Глушит access-логи health-проверок и опросов самого просмотрщика логов."""

    def filter(self, record):
        global _dropped_health
        try:
            msg = record.getMessage()
            if any(p in msg for p in QUIET_PATHS):
                with _lock:
                    _dropped_health += 1
                return False
        except Exception:
            pass
        return True


class _Tee:
    """Обёртка потока: пишет в оригинал и складывает полные строки в буфер.

    Строки аккумулируются (write может прийти без "\\n") — в буфер попадают
    только завершённые строки, как в настоящей консоли.
    """

    def __init__(self, original, name):
        self._original = original
        self._name = name
        self._pending = ""

    # -- основной контракт -------------------------------------------------
    def write(self, s):
        if isinstance(s, bytes):
            try:
                s = s.decode("utf-8", "replace")
            except Exception:
                s = str(s)
        try:
            self._original.write(s)
        except Exception:
            pass
        if s:
            self._pending += s
            while "\n" in self._pending:
                line, self._pending = self._pending.split("\n", 1)
                _push(line)
            # чтобы консоль (Render) не отставала при блокированном буфере
            try:
                self._original.flush()
            except Exception:
                pass
        return len(s)

    def flush(self):
        try:
            self._original.flush()
        except Exception:
            pass

    # -- атрибуты, которые могут ожидать сторонние библиотеки ---------------
    def isatty(self):
        try:
            return self._original.isatty()
        except Exception:
            return False

    def fileno(self):
        return self._original.fileno()

    @property
    def encoding(self):
        return getattr(self._original, "encoding", "utf-8")

    @property
    def name(self):
        return self._name

    def readable(self):
        return False

    def writable(self):
        return True

    def seekable(self):
        return False


def _push(line: str):
    line = _ANSI_RE.sub("", line).rstrip()
    if not line:
        return
    global _lines
    with _lock:
        _lines.append(line)
        excess = len(_lines) - CAPACITY
        if excess > 0:
            del _lines[:excess]


# ---- публичный API -------------------------------------------------------

def setup():
    """Включает перехват. Вызывать до uvicorn.run (мы вызываем при импорте
    iphone_server, до импорта flet/uvicorn — тогда попадает вообще всё)."""
    global _installed
    if _installed:
        return
    _installed = True

    orig_out, orig_err = sys.stdout, sys.stderr

    # 1) фильтр health-спама у uvicorn.access (переживёт dictConfig:
    #    dictConfig сбрасывает handlers, но не filters логгера)
    logging.getLogger("uvicorn.access").addFilter(_HealthFilter())

    # 2) tee stdout/stderr
    sys.stdout = _Tee(orig_out, "stdout")
    sys.stderr = _Tee(orig_err, "stderr")

    # 3) обработчики, созданные ДО нас (logging.basicConfig в iphone_server)
    #    держат ссылку на исходный stderr — перенаправим их в tee, иначе их
    #    строки (например, INFO:flet_web...) не попали бы в буфер.
    for h in logging.getLogger().handlers:
        stream = getattr(h, "stream", None)
        if stream is orig_out:
            h.stream = sys.stdout
        elif stream is orig_err:
            h.stream = sys.stderr

    _push(f"— буфер логов запущен (храню последние {CAPACITY} строк) —")


def recent(limit: int = 500, contains: str = "") -> list:
    """Последние `limit` строк буфера; с фильтром по подстроке, если задана."""
    with _lock:
        snapshot = list(_lines)
    if contains:
        needle = contains.lower()
        snapshot = [ln for ln in snapshot if needle in ln.lower()]
    return snapshot[-max(1, limit):]


def stats() -> dict:
    with _lock:
        total = len(_lines)
        dropped = _dropped_health
    return {
        "total": total,
        "capacity": CAPACITY,
        "dropped_health": dropped,
        "uptime_sec": int(time.time() - _started_at),
    }


def clear():
    with _lock:
        _lines.clear()
        _lines.append("— буфер логов очищен вручную —")
