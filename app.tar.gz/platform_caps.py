# platform_caps.py
"""Определение возможностей платформы (однократно, с кэшем).

На веб-сервере (Render/PWA) модуля jnius нет — и это НОРМАЛЬНО:
Android-будильники и SharedPreferences существуют только на телефоне.
Раньше каждый такой вызов печатал ошибку в лог (спам каждые 30 секунд
от планировщика), теперь проверка делается один раз, а Android-ветки
код молча пропускает.
"""
import threading

_lock = threading.Lock()
_android = None  # None = ещё не проверяли


def android_available() -> bool:
    """True, если pyjnius доступен (приложение запущено на Android)."""
    global _android
    if _android is None:
        with _lock:
            if _android is None:
                try:
                    import jnius  # noqa: F401
                    _android = True
                except Exception:
                    _android = False
                    print("[platform] Android (jnius) недоступен — "
                          "нативные функции телефона отключены (норма для веб)")
    return _android
