# pycompat.py
"""Совместимость CPython и Pyodide (статическая сборка `flet publish`).

В Pyodide (Python в браузере) нет реальных потоков: threading.Thread и
ThreadPoolExecutor не работают. Поэтому всё, что на CPython уходит в
run_in_executor, в Pyodide выполняется напрямую (браузер однопоточный —
блокировки UI на время сетевого вызова неизбежны, но это допустимо:
Firestore REST отвечает за 100-300 мс).

Использование:
    from pycompat import run_io
    result = await run_io(sync_once, db, fs, uid, do_pull=True)
"""
import sys
import asyncio
import functools

# Pyodide выставляет sys.platform == "emscripten".
IS_PYODIDE = sys.platform == "emscripten"


async def run_io(fn, *args, **kwargs):
    """Выполняет блокирующий fn: в executor'е на CPython, напрямую в Pyodide."""
    if IS_PYODIDE:
        return fn(*args, **kwargs)
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(fn, *args, **kwargs))
