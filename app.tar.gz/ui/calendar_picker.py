"""Календарь выбора даты с цветовой индикацией подходящих задач."""
import calendar
from datetime import date, datetime
from ui.components import elevated_button
import flet as ft


MONTHS_RU = (
    "январь", "февраль", "март", "апрель", "май", "июнь",
    "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь",
)
WEEKDAYS_RU = ("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")


def _task_counts(repo):
    """Считает разовые и повторяющиеся, кроме ежедневных, задачи по датам."""
    counts = {}
    try:
        tasks = repo.get_all_tasks()
    except Exception:
        tasks = []

    for task in tasks:
        repeat = task.get("repeat")
        repeat_type = repeat.get("type") if isinstance(repeat, dict) else None
        if repeat_type == "daily":
            continue
        value = str(task.get("datetime") or "")
        if len(value) < 10:
            continue
        try:
            day = date.fromisoformat(value[:10])
        except ValueError:
            continue
        counts[day] = counts.get(day, 0) + 1
    return counts


def _count_color(count, palette):
    if count == 1:
        return palette["success"]
    if count <= 3:
        return palette["warning"]
    return palette["danger"]


def show_task_date_picker(page, repo, palette, initial_date, on_select, on_dismiss=None):
    """Показывает календарь и возвращает выбранный локальный date в on_select."""
    counts = _task_counts(repo)
    if isinstance(initial_date, datetime):
        initial_date = initial_date.date()
    selected = {"date": initial_date if isinstance(initial_date, date) else date.today()}
    visible = {"year": selected["date"].year, "month": selected["date"].month}
    dialog_ref = {"dialog": None}

    def set_month(delta):
        month_index = visible["year"] * 12 + visible["month"] - 1 + delta
        visible["year"], month_zero = divmod(month_index, 12)
        visible["month"] = month_zero + 1
        redraw()

    def choose_day(day):
        selected["date"] = day
        redraw()

    def accept():
        page.pop_dialog()
        on_select(selected["date"])

    def choose_year(year):
        page.pop_dialog()
        visible["year"] = year
        max_day = calendar.monthrange(year, visible["month"])[1]
        if selected["date"].year != year:
            selected["date"] = date(year, visible["month"], min(selected["date"].day, max_day))
        redraw()

    def open_year_picker():
        current_year = visible["year"]
        years = [current_year]
        years.extend(range(current_year + 1, 2101))
        years.extend(range(current_year - 1, 1899, -1))
        year_list = ft.ListView(
            controls=[
                ft.TextButton(
                    content=ft.Text(str(year), color=palette["accent"] if year == current_year else palette["text"], size=15),
                    on_click=lambda e, y=year: choose_year(y),
                )
                for year in years
            ],
            height=320,
            spacing=0,
        )
        year_dialog = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Выберите год", color=palette["text"], size=17),
            content=ft.Container(width=220, height=320, content=year_list),
            actions=[ft.TextButton(content=ft.Text("Отмена", color=palette["text_muted"]), on_click=lambda e: page.pop_dialog())],
        )
        page.show_dialog(year_dialog)

    def make_day_cell(day):
        if day is None:
            return ft.Container(width=36, height=40)

        count = counts.get(day, 0)
        is_selected = day == selected["date"]
        count_text = ft.Text(
            str(count) if count else " ",
            color=_count_color(count, palette) if count else palette["text_muted"],
            size=10,
            weight=ft.FontWeight.W_700,
            text_align=ft.TextAlign.CENTER,
        )
        day_text = ft.Text(
            str(day.day), color=palette["text"], size=14,
            text_align=ft.TextAlign.CENTER,
        )
        
        # --- ИЗМЕНЕНИЯ ЗДЕСЬ ---
        day_chip = ft.Container(
            content=day_text,
            width=32,
            height=28, # Увеличили высоту с 24 до 28
            alignment=ft.Alignment.CENTER,
            padding=ft.Padding.only(bottom=2), # Чуть сдвинули текст вверх
            bgcolor=palette["surface3"] if is_selected else None,
            border=ft.Border.all(2, palette["accent"]) if is_selected else None,
            border_radius=8,
        )
        # -----------------------

        return ft.Container(
            content=ft.Column(
                controls=[
                    ft.Container(content=count_text, width=36, height=14,
                                 alignment=ft.Alignment.CENTER),
                    day_chip,
                ],
                spacing=0,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            width=36,
            height=40,
            alignment=ft.Alignment.CENTER,
            on_click=lambda e, chosen=day: choose_day(chosen),
            ink=True,
        )

    def legend_item(label, color):
        return ft.Row(
            tight=True,
            spacing=4,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Container(width=8, height=8, bgcolor=color, border_radius=4),
                ft.Text(label, color=palette["text_muted"], size=10),
            ],
        )

    def build_content():
        year, month = visible["year"], visible["month"]
        month_title = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.TextButton(content=ft.Text("‹", size=24, color=palette["text"]), on_click=lambda e: set_month(-1)),
                ft.TextButton(
                    content=ft.Text(f"{MONTHS_RU[month - 1].capitalize()} {year}", color=palette["text"], size=15, weight=ft.FontWeight.W_600),
                    on_click=lambda e: open_year_picker(),
                ),
                ft.TextButton(content=ft.Text("›", size=24, color=palette["text"]), on_click=lambda e: set_month(1)),
            ],
        )
        weekday_row = ft.Row(
            spacing=0,
            controls=[
                ft.Container(width=36, height=24, alignment=ft.Alignment.CENTER,
                             content=ft.Text(label, color=palette["text_muted"], size=10))
                for label in WEEKDAYS_RU
            ],
        )
        month_weeks = calendar.Calendar(firstweekday=0).monthdatescalendar(year, month)
        while len(month_weeks) < 6:
            last_week = month_weeks[-1]
            next_start = last_week[-1].toordinal() + 1
            month_weeks.append([date.fromordinal(next_start + offset) for offset in range(7)])
        week_rows = [
            ft.Row(controls=[make_day_cell(day if day.month == month else None) for day in week], spacing=0)
            for week in month_weeks[:6]
        ]
        legend = ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=10,
            controls=[legend_item("1", palette["success"]), legend_item("2–3", palette["warning"]), legend_item("4+", palette["danger"])],
        )
        return ft.Column(
            tight=True, spacing=4,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            controls=[month_title, weekday_row, *week_rows, legend],
        )

    def on_dialog_dismiss(e):
        if on_dismiss:
            on_dismiss()

    def redraw():
        dialog = dialog_ref["dialog"]
        if dialog is not None:
            dialog.content = ft.Container(width=260, content=build_content())
            dialog.update()

    dialog_ref["dialog"] = ft.AlertDialog(
        modal=True,
        on_dismiss=on_dialog_dismiss,
        bgcolor=palette["surface"],
        title=ft.Text("Выберите дату", color=palette["text"], size=17),
        title_padding=ft.Padding.only(left=16, top=14, right=16, bottom=4),
        content_padding=ft.Padding.only(left=8, top=6, right=8, bottom=6),
        actions_padding=ft.Padding.only(left=16, top=0, right=16, bottom=10),
        inset_padding=ft.Padding.only(left=8, top=16, right=8, bottom=16),
        content=ft.Container(width=260, content=build_content()),
        actions=[
            ft.Row(
                controls=[
                    elevated_button("Отмена", lambda e: page.pop_dialog(), palette, primary=False, expand=True),
                    ft.Container(width=10),
                    elevated_button("Выбрать", lambda e: accept(), palette, primary=True, expand=True),
                ],
                spacing=0,
            ),
        ],
    )
    page.show_dialog(dialog_ref["dialog"])
