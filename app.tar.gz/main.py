"""Точка входа мобильного приложения."""
import os
import sys
import json
import asyncio
import traceback
import flet as ft
from views.settings_view import build_settings_view

# --- Pyodide (статическая сборка через `flet publish`) ---
# В Pyodide нет raw-сокетов: requests работает только через браузерный
# XMLHttpRequest. Шим pyodide-http патчит requests/urllib3. На CPython
# (десктоп/сервер) модуль не импортируется — это no-op.
IS_PYODIDE = sys.platform == "emscripten"
if IS_PYODIDE:
    try:
        import pyodide_http
        pyodide_http.patch_all()
        print("[pyodide] requests/urllib patched for browser")
    except Exception as ex:
        print(f"[pyodide] patch error: {ex}")

def _app_data_dir() -> str:
    env = os.getenv("FLET_APP_STORAGE_DATA")
    if env:
        return env
    return os.path.dirname(os.path.abspath(__file__))


# Каталог данных (для per-session БД в multiuser-режиме)
DATA_DIR = _app_data_dir()

# Мультипользовательский сервер (Render/PWA): сессии изолированы друг от
# друга. Включается iphone_server.py / Dockerfile. На десктопе/Android — 0.
# В Pyodide (статическая сборка) всегда multiuser: токен живёт в localStorage
# браузера, а файловый диск эфемерен — хранить на нём нечего.
MULTIUSER = os.getenv("FLET_MULTIUSER", "0") == "1" or IS_PYODIDE

# БД «по умолчанию» (однопользовательский режим + API часовых поясов на
# сервере). В multiuser каждая сессия получает СВОЙ файл — см. main().
DB_PATH = os.path.join(DATA_DIR, "ordnung.db")


async def main(page: ft.Page):
    page.title = "Ежедневник"
    page.padding = 0
    page.spacing = 0

    # --- ФИКС ЛОКАЛИЗАЦИИ (Copy/Paste на русском) ---
    try:
        page.locale_configuration = ft.LocaleConfiguration(
            supported_locales=[
                ft.Locale(language_code="ru", country_code="RU"),
                ft.Locale(language_code="en", country_code="US"),
            ],
            current_locale=ft.Locale(language_code="ru", country_code="RU"),
        )
    except Exception as ex:
        print(f"[init] locale config error: {ex}")
    # ------------------------------------------------

    page.theme = ft.Theme(
        page_transitions=ft.PageTransitionsTheme(
            android=ft.PageTransitionTheme.NONE,
            ios=ft.PageTransitionTheme.NONE,
            linux=ft.PageTransitionTheme.NONE,
            macos=ft.PageTransitionTheme.NONE,
            windows=ft.PageTransitionTheme.NONE,
        )
    )

    # ============ Инициализация ============
    from cloud.session_manager import SessionManager
    session = SessionManager(multiuser=MULTIUSER)

    # ---- «Запомнить меня» на устройстве (multiuser: localStorage браузера) ----
    # Токен НЕ хранится на сервере — иначе второй пользователь получал бы
    # аккаунт первого. Храним его в SharedPreferences устройства и
    # восстанавливаем при запуске сессии.
    from flet.controls.services.shared_preferences import SharedPreferences

    async def _prefs_get(key: str):
        try:
            return await SharedPreferences().get(key)
        except Exception as ex:
            print(f"[auth] prefs get error: {ex}")
            return None

    async def _prefs_set(key: str, value: str) -> None:
        try:
            await SharedPreferences().set(key, value)
        except Exception as ex:
            print(f"[auth] prefs set error: {ex}")

    async def _prefs_remove(key: str) -> None:
        try:
            await SharedPreferences().remove(key)
        except Exception as ex:
            print(f"[auth] prefs remove error: {ex}")

    if MULTIUSER:
        saved = await _prefs_get("auth_session")
        print(f"[auth] restore: saved={'present' if saved else 'absent'}")
        if saved:
            try:
                # SharedPreferences может вернуть и строку (json), и уже
                # распарсенный dict — зависит от того, как значение записано.
                state = saved if isinstance(saved, dict) else json.loads(saved)
                if session.restore(state):
                    try:
                        session.ensure_fresh_token()
                        print(f"[auth] session restored from device: "
                              f"{session.email}")
                    except Exception as ex:
                        # refreshToken протух — выкидываем на логин
                        print(f"[auth] saved token stale, clearing: {ex}")
                        session.logout()
                        await _prefs_remove("auth_session")
            except Exception as ex:
                print(f"[auth] restore error: {ex}")

    # ---- БД сессии ----
    # В multiuser у каждой сессии СВОЙ файл БД (данные — в Firebase, локальный
    # SQLite — лишь кэш). Раньше файл ordnung.db был общий: данные смешивались
    # между пользователями и сессиями.
    session_db_path = DB_PATH
    if MULTIUSER:
        try:
            sid = str(page.session.id or "") if page.session else ""
        except Exception:
            sid = ""
        sid = "".join(c for c in sid if c.isalnum() or c in "-_")[:64]
        if sid:
            session_db_path = os.path.join(DATA_DIR, f"session_{sid}.db")

    from db.local_db import LocalDB
    db = LocalDB(session_db_path)
    db.init_schema()

    # ---- WASM: постоянное хранилище задач в браузере ----
    # SQLite в Pyodide живёт в memfs и пропадает при перезагрузке страницы.
    # Снапшот таблиц держим в localStorage (SharedPreferences — тот же
    # канал, что и auth_session): офлайн-старт показывает последние
    # данные + очередь изменений (pending_*), онлайн-синхронизация с
    # Firestore их выталкивает/освежает. На сервере/десктопе ветка молчит.
    db_store = None
    if IS_PYODIDE:
        try:
            from db.db_persist import BrowserDBStore
            db_store = BrowserDBStore(
                db=db,
                get_uid=lambda: session.uid or "",
                prefs_get=_prefs_get,
                prefs_set=_prefs_set,
                prefs_remove=_prefs_remove,
            )
            if session.uid:
                restored = await db_store.restore()
                if restored:
                    print(f"[init] офлайн-данные восстановлены "
                          f"из браузерного хранилища ({restored} строк)")
            # Автосохранение после каждой мутации (debounce внутри)
            db.on_change = db_store.schedule_save

            # Flush при уходе страницы в фон (сворачивание PWA / таба):
            # debounce может не успеть — сохраняем немедленно.
            _FLUSH_STATES = (ft.AppLifecycleState.HIDE, ft.AppLifecycleState.PAUSE,
                             ft.AppLifecycleState.DETACH, ft.AppLifecycleState.INACTIVE)

            async def _on_lifecycle(state):
                if db_store is not None and state in _FLUSH_STATES:
                    try:
                        await db_store.save_now()
                    except Exception as ex:
                        print(f"[persist] flush on hide error: {ex}")

            try:
                page.on_app_lifecycle_state_change = _on_lifecycle
            except Exception as ex:
                print(f"[persist] lifecycle hook unavailable: {ex}")
        except Exception as ex:
            print(f"[persist] init error: {ex}")

    from repository.task_repository import TaskRepository
    from notifications import ReminderStorage

    reminder_storage_early = ReminderStorage(db)
    repo = TaskRepository(db, session, reminder_storage=reminder_storage_early)

    last_uid = repo.get_setting("last_uid", "")
    current_uid = session.uid or ""
    if last_uid and last_uid != current_uid:
        print(f"[init] uid changed: {last_uid} -> {current_uid}, clearing DB")
        db.clear_all_tasks()
    if current_uid:
        repo.set_setting("last_uid", current_uid)
        # Синхронизируем last_pull_ts для текущего UID — принудительно full-pull
        try:
            pull_key = f"last_pull_ts_{current_uid}"
            db.set_setting(pull_key, "0")
        except Exception:
            pass

    from ui.theme import apply_theme, get_palette, toggle_theme_name
    from views.login_view import build_login_view
    from views.tasks_view import build_tasks_view
    from views.task_edit_view import build_task_edit_view
    from sync.sync_loop import SyncLoop
    from notifications import ReminderStorage, ReminderScheduler, get_default_backend

    theme_name = repo.get_setting("theme", "dark")
    apply_theme(page, theme_name)
    palette = get_palette(theme_name)

    # ============ Состояние ============
    sync_loop_ref = {"loop": None}
    sync_overlay_ref = {"show": None, "hide": None, "refresh": None}
    reminder_ref = {"storage": None, "scheduler": None, "backend": None}
    overdue_check_ref = {"checked_after_login": False}
    nav_state = {
        "edit_task_id": None,
        "edit_category": "personal",
        "edit_date": None,
        "copy_from_id": None,
    }

    # ============ Хелпер: размер шрифта ============
    def _get_font_scale() -> float:
        try:
            v = repo.get_setting("ui_font_scale", "1.0") or "1.0"
            f = float(v)
            if f < 0.8:
                f = 0.8
            if f > 2.0:
                f = 2.0
            return f
        except Exception:
            return 1.0

    def _refresh_tasks_after_settings(changes):
        """Refresh only the task UI elements affected by settings."""
        if not changes:
            return
        if changes.get("font_scale"):
            for index, view in enumerate(page.views):
                if view.route == "/tasks":
                    page.views[index] = _ensure_view(
                        build_view_for_route("/tasks"), "/tasks"
                    )
                    page.update()
                    refs = getattr(page, "_tasks_view_refs", None)
                    if refs:
                        sync_overlay_ref["show"] = refs.get("show")
                        sync_overlay_ref["hide"] = refs.get("hide")
                        sync_overlay_ref["refresh"] = refs.get("refresh")
                    return
        if changes.get("visible_icons"):
            refs = getattr(page, "_tasks_view_refs", None)
            if refs and refs.get("refresh"):
                refs["refresh"]()

        if changes.get("categories_enabled"):
            refs = getattr(page, "_tasks_view_refs", None)
            if refs and refs.get("set_categories_enabled"):
                enabled = (repo.get_setting("categories_enabled", "1") or "1") == "1"
                refs["set_categories_enabled"](enabled)

    # ============ Навигация ============
    def _go(route: str):
        async def _go_dispatch():
            try:
                await page.push_route(route)
            except Exception as ex:
                print(f"[nav] push_route error: {ex}")
            # push_route НЕ диспатчит on_route_change, если маршрут уже равен
            # целевому (перезагрузка страницы с сохранённым hash — например,
            # офлайн-старт WASM-версии или повторное открытие PWA): flet
            # считает, что маршрут не менялся. Тогда строим views сами,
            # иначе пользователь видит пустой экран.
            try:
                if not any(v.route == route for v in page.views):
                    print(f"[nav] push_route без события (route уже {route}) — диспатчим вручную")
                    on_route_change(None)
            except Exception as ex:
                print(f"[nav] manual route dispatch error: {ex}")
        try:
            asyncio.get_running_loop().create_task(_go_dispatch())
        except Exception as ex:
            print(f"[nav] push_route error: {ex}, unable to schedule route")
            try:
                raise ex
            except Exception as ex2:
                print(f"[nav] route scheduling failed: {ex2}")

    # ============ Смена темы ============
    _theme_lock = {"busy": False}

    def on_toggle_theme(e):
        nonlocal palette
        if _theme_lock["busy"]:
            return
        _theme_lock["busy"] = True
        try:
            current = repo.get_setting("theme", "dark")
            new_name = toggle_theme_name(current)
            repo.set_setting("theme", new_name)
            apply_theme(page, new_name, update=False)
            palette = get_palette(new_name)

            if page.route in ("/tasks", "/"):
                refs = getattr(page, "_tasks_view_refs", None)
            else:
                refs = getattr(page, "_login_view_refs", None)
            apply_palette = refs.get("apply_palette") if refs else None
            if apply_palette:
                apply_palette(palette)
            else:
                _rebuild_current_views()
        finally:
            async def _release():
                import asyncio
                await asyncio.sleep(0.5)
                _theme_lock["busy"] = False
            asyncio.create_task(_release())

    # ============ Открытие редактора ============
    def open_edit(task_id=None, category="personal", selected_date=None):
        nav_state["edit_task_id"] = task_id
        nav_state["edit_category"] = category or "personal"
        nav_state["edit_date"] = selected_date
        nav_state["copy_from_id"] = None
        _go("/edit" if task_id else "/new")

    def open_copy(task_id, category="personal", selected_date=None):
        nav_state["edit_task_id"] = None
        nav_state["edit_category"] = category or "personal"
        nav_state["edit_date"] = selected_date
        nav_state["copy_from_id"] = task_id
        _go("/new")

    # ============ Сохранение ============
    def handle_save():
        refs = getattr(page, "_tasks_view_refs", None)
        if refs and refs.get("refresh"):
            refs["refresh"]()
        nav_state["copy_from_id"] = None
        _go("/tasks")
        if sync_loop_ref.get("loop"):
            try:
                page.run_task(sync_loop_ref["loop"].sync_now)
            except Exception as ex:
                print(f"[save] sync trigger error: {ex}")

    # ============ Роутинг ============
    def show_login():
        _go("/login")

    async def on_login_success():
        try:
            print("[login] start")
            last_uid = repo.get_setting("last_uid", "")
            if last_uid and last_uid != session.uid:
                print(f"[login] uid changed → clearing DB")
                db.clear_all_tasks()
            repo.set_setting("last_uid", session.uid)

            # Токен — на УСТРОЙСТВО (localStorage), не на диск сервера:
            # именно так «запомнить меня» работает отдельно на каждом устройстве
            if MULTIUSER:
                state = session.export_state()
                if state:
                    await _prefs_set("auth_session", json.dumps(state))
                    print("[auth] token saved to device storage")

            # Принудительный full-pull при каждом логине,
            # чтобы локальная очистка не оставила «дыр» в данных
            try:
                if session.uid:
                    pull_key = f"last_pull_ts_{session.uid}"
                    db.set_setting(pull_key, "0")
                    print(f"[login] reset {pull_key} to 0 (force full pull)")
            except Exception as ex:
                print(f"[login] reset pull ts error: {ex}")

            show_tasks()
        
            
            overdue_check_ref["checked_after_login"] = False
            if reminder_ref.get("backend"):
                try:
                    ok = await reminder_ref["backend"].request_permissions()
                    print(f"[login] notification permission: {ok}")
                except Exception as ex:
                    print(f"[login] permission error: {ex}")

            if sync_loop_ref.get("loop"):
                try:
                    r = await sync_loop_ref["loop"].sync_now_pull()
                    print(f"[login] sync result: {r}")
                except Exception as ex:
                    print(f"[login] sync error: {type(ex).__name__}: {ex}")

                refs = getattr(page, "_tasks_view_refs", None)
                if refs and refs.get("refresh"):
                    try:
                        refs["refresh"]()
                    except Exception as ex:
                        print(f"[login] refresh error: {ex}")
            print("[login] done")
            
        except Exception:
            print("[login] FATAL:")
            print(traceback.format_exc())

    # ============ In-app напоминания (браузер / iPhone-PWA / десктоп) ============
    def _open_task_from_notify(task_id):
        """Тап по SnackBar напоминания — открываем карточку задачи."""
        try:
            if page.route not in ("/tasks", "/"):
                asyncio.create_task(page.push_route("/tasks"))
            refs = getattr(page, "_tasks_view_refs", None)
            open_details = refs.get("open_task_details") if refs else None
            if open_details:
                open_details(task_id)
        except Exception as ex:
            print(f"[notify] open task from notification error: {ex}")

    def _in_app_notify(title, body, extra=None):
        """Баннер напоминания поверх экрана — работает в любой сессии.
        На Android системное уведомление шлёт Kotlin; на iPhone-PWA системное
        уведомление доставит Web Push, а SnackBar — дублирующий in-app вариант."""
        extra = extra or {}
        try:
            task_id = int(extra.get("task_id") or extra.get("id") or 0)
            bar = ft.SnackBar(
                content=ft.Row(
                    controls=[
                        ft.Icon(ft.Icons.NOTIFICATIONS_ACTIVE,
                                color=palette["accent"]),
                        ft.Text(
                            f"{title}: {body}" if body else title,
                            color=palette["text"], size=14, expand=True,
                        ),
                    ],
                    spacing=10,
                ),
                bgcolor=palette["surface2"],
                duration=8000,
                action="Открыть" if task_id else "OK",
                on_action=(lambda e, tid=task_id: _open_task_from_notify(tid))
                          if task_id else None,
            )
            page.show_dialog(bar)
            print(f"[notify] in-app snackbar shown: {title}")
        except Exception as ex:
            print(f"[notify] in-app show error: {ex}")

    def show_tasks():
        print("[show_tasks] enter")

        # --- ПРОВЕРКА И ПЕРЕНОС ЗАДАЧ ПРИ СТАРТЕ ---
        carry_enabled = (repo.get_setting("carry_over_singles", "1") or "1") == "1"
        if carry_enabled:
            try:
                repo.carry_over_uncompleted_singles()
            except Exception as ex:
                print(f"[show_tasks] carry_over error: {ex}")
        # -------------------------------------------

        if sync_loop_ref.get("loop"):
            try:
                page.run_task(sync_loop_ref["loop"].stop)
            except Exception:
                pass
            sync_loop_ref["loop"] = None


        def on_sync_result(result):
            print(f"[sync] result: {result}")
            if (result.pulled_new or result.pulled_updated or result.pulled_deleted):
                if page.route in ("/tasks", "/"):
                    refs = getattr(page, "_tasks_view_refs", None)
                    if refs and refs.get("refresh"):
                        try:
                            refs["refresh"]()
                        except Exception as ex:
                            print(f"[sync] refresh error: {ex}")

        def on_sync_error(err):
            print(f"[sync] error: {type(err).__name__}: {err}")

        initial_interval = 180
        try:
            v = db.get_setting("sync_interval", "180") or "180"
            initial_interval = max(30, int(v))
        except Exception:
            initial_interval = 180

        loop = SyncLoop(
            db=db, session=session, interval=initial_interval,
            on_result=on_sync_result, on_error=on_sync_error,
            pull_on_tick=True,
        )
        loop.start()
        sync_loop_ref["loop"] = loop
        print(f"[show_tasks] loop created: {loop}")
        asyncio.create_task(_open_notification_task_if_pending())

        if reminder_ref["scheduler"] is None:
            reminder_storage = reminder_storage_early
            reminder_backend = get_default_backend(
                on_show=_in_app_notify,
                page=page,
                uid_provider=lambda: session.uid,
            )
            reminder_scheduler = ReminderScheduler(
                storage=reminder_storage,
                backend=reminder_backend,
                tick_interval=30,
                on_fired=None,
                task_status_getter=lambda tid: (db.get_task(tid) or {}).get("status", 0),
            )
            reminder_scheduler.start()
            reminder_ref["storage"] = reminder_storage
            reminder_ref["backend"] = reminder_backend
            reminder_ref["scheduler"] = reminder_scheduler
            print("[show_tasks] reminder scheduler started")

            try:
                from notifications.alarm_manager import clear_legacy_channels
                clear_legacy_channels()
            except Exception as ex:
                print(f"[show_tasks] clear legacy channels error: {ex}")

        _go("/tasks")

    def on_logout():
        if sync_loop_ref.get("loop"):
            try:
                page.run_task(sync_loop_ref["loop"].stop)
            except Exception:
                pass
            sync_loop_ref["loop"] = None

        if reminder_ref.get("scheduler"):
            try:
                page.run_task(reminder_ref["scheduler"].stop)
            except Exception:
                pass
            reminder_ref["scheduler"] = None

        sync_overlay_ref["show"] = None
        sync_overlay_ref["hide"] = None
        sync_overlay_ref["refresh"] = None
        # Убираем токен и офлайн-снапшот этого пользователя с устройства
        # (в multiuser они только в localStorage)
        if MULTIUSER:
            _logout_uid = session.uid or ""  # ДО session.logout()

            async def _clear_device_storage():
                await _prefs_remove("auth_session")
                if db_store is not None:
                    await db_store.clear(_logout_uid)
            try:
                page.run_task(_clear_device_storage)
            except Exception as ex:
                print(f"[logout] clear prefs error: {ex}")
        session.logout()
        _go("/login")

    # ============ Сборка view ============
    def build_view_for_route(route: str):
        if route == "/login":
            return build_login_view(
                page=page, session=session, palette=palette,
                on_success=lambda: page.run_task(on_login_success),
                on_toggle_theme=on_toggle_theme,
            )

        if route in ("/edit", "/new"):
            return build_task_edit_view(
                page=page, repo=repo, palette=palette,
                task_id=nav_state["edit_task_id"],
                copy_from_id=nav_state.get("copy_from_id"),
                initial_category=nav_state.get("edit_category", "personal"),
                initial_date=nav_state.get("edit_date"),
                on_save=handle_save,
                on_back=lambda: _go("/tasks"),
                font_scale=_get_font_scale(),   
            )

        if route == "/settings":
            return build_settings_view(
                page=page, repo=repo, palette=palette, session=session,
                on_logout=on_logout,
                on_back=lambda: _go("/tasks"),
                on_save=_refresh_tasks_after_settings
            )

        return build_tasks_view(
            page=page, session=session, repo=repo, palette=palette,
            sync_loop=sync_loop_ref.get("loop"),
            on_logout=on_logout,
            on_toggle_theme=on_toggle_theme,
            on_edit_task=open_edit,
            on_copy_task=open_copy,
            on_settings=_refresh_tasks_after_settings,
            font_scale=_get_font_scale(),       
        )

    def _ensure_view(control, route):
        if isinstance(control, ft.View):
            return control
        return ft.View(
            route=route,
            controls=[ft.SafeArea(content=control, expand=True)],
            padding=0,
            spacing=0,
            bgcolor=palette["bg"],
        )

    def _prepare_views_for_route(route: str):
        """Preserve the mounted tasks View; drop only views above it."""
        if route in ("/tasks", "/", "/edit", "/new", "/settings") and any(
            view.route == "/tasks" for view in page.views
        ):
            while len(page.views) > 1:
                page.views.pop()
        else:
            page.views.clear()

    def build_stack_for_route(route: str):
        views = []
        if route == "/login":
            views.append(_ensure_view(build_view_for_route("/login"), "/login"))
            return views

        existing_tasks = next(
            (view for view in page.views if view.route == "/tasks"), None
        )
        if existing_tasks is None:
            views.append(_ensure_view(build_view_for_route("/tasks"), "/tasks"))

        if route in ("/edit", "/new", "/settings"):
            views.append(_ensure_view(build_view_for_route(route), route))
        return views

    def _rebuild_current_views():
        """Fallback for routes without an in-place palette updater."""
        routes = [view.route for view in page.views]
        if not routes:
            routes = ["/login" if not session.is_authenticated else "/tasks"]
        new_views = [
            _ensure_view(build_view_for_route(route), route) for route in routes
        ]
        page.views[:] = new_views
        page.update()

    # ============ Обработчики ============
    def on_route_change(e):
        print(f"[nav] route={page.route}, views_old={len(page.views)}")
        try:
            if page.overlay:
                page.overlay.clear()
                print("[nav] cleared overlays on route change")
        except Exception as ex:
            print(f"[nav] clear overlays error: {ex}")
        try:
            _prepare_views_for_route(page.route)
            for v in build_stack_for_route(page.route):
                page.views.append(v)
            page.update()

            if page.route in ("/tasks", "/"):
                refs = getattr(page, "_tasks_view_refs", None)
                if refs:
                    sync_overlay_ref["show"] = refs.get("show")
                    sync_overlay_ref["hide"] = refs.get("hide")
                    sync_overlay_ref["refresh"] = refs.get("refresh")
                    print(f"[nav] refs updated: show={bool(sync_overlay_ref['show'])}, "
                          f"hide={bool(sync_overlay_ref['hide'])}, "
                          f"refresh={bool(sync_overlay_ref['refresh'])}")

                # Проверка просроченных повторяющихся задач — раз в сессию
                if refs and refs.get("check_overdue") and \
                        not overdue_check_ref["checked_after_login"]:
                    overdue_check_ref["checked_after_login"] = True
                    async def _delayed_overdue_check():
                        await asyncio.sleep(0.8)  # дать экрану отрисоваться
                        try:
                            refs["check_overdue"]()
                        except Exception as ex:
                            print(f"[overdue] check_overdue error: {ex}")
                    page.run_task(_delayed_overdue_check)
        except Exception:
            print("[nav] FATAL:")
            print(traceback.format_exc())
        print(f"[nav] views_new={len(page.views)}")

    def _force_refresh_tasks():
        """Legacy entry point; settings now refresh only affected controls."""
        return
        print(f"[nav] force refresh, route={page.route}")

        async def _do():
            import asyncio
            try:
                # 1) Полностью опустошаем и коммитим пустое состояние
                _prepare_views_for_route(page.route)
                page.update()
                # 2) Даём фреймворку «переварить» пустые views
                await asyncio.sleep(0.05)
                # 3) Наполняем заново с актуальными настройками
                for v in build_stack_for_route(page.route):
                    page.views.append(v)
                page.update()
                print("[nav] force refresh done")
            except Exception as ex:
                print(f"[nav] force refresh error: {ex}")
                import traceback
                print(traceback.format_exc())

        try:
            page.run_task(_do)
        except Exception as ex:
            print(f"[nav] run_task force refresh error: {ex}")

    async def on_view_pop(e):
        print(f"[nav] on_view_pop, route={page.route}, views={len(page.views)}")
        if len(page.views) <= 1:
            return
        popped = getattr(e, "view", None)
        if popped in page.views:
            page.views.remove(popped)
        else:
            page.views.pop()
        await page.push_route(page.views[-1].route)

    page.on_route_change = on_route_change
    page.on_view_pop = on_view_pop

    # ============ Закрытие ============
    def _remove_session_db_files():
        """Multiuser: удаляем SQLite-файл сессии (кэш, не источник истины)."""
        if not MULTIUSER:
            return
        base = getattr(db, "db_path", "") or session_db_path
        for suffix in ("", "-wal", "-shm"):
            try:
                fp = base + suffix
                if os.path.exists(fp):
                    os.remove(fp)
            except Exception:
                pass

    async def on_close_async():
        if sync_loop_ref.get("loop"):
            try:
                await sync_loop_ref["loop"].stop()
            except Exception:
                pass
        if reminder_ref.get("scheduler"):
            try:
                await reminder_ref["scheduler"].stop()
            except Exception:
                pass
        try:
            db.close()
        except Exception:
            pass
        _remove_session_db_files()

    def _session_teardown_sync():
        """Фолбэк: остановка фоновых задач сессии «по флагу», без event loop.
        Нужен, если живого цикла уже нет — иначе задачи закрытой сессии
        продолжали бы крутиться на сервере (утечка)."""
        sl = sync_loop_ref.get("loop")
        if sl:
            try:
                sl.request_stop()
                print("[close] sync loop: флаг остановки установлен")
            except Exception:
                pass
        rs = reminder_ref.get("scheduler")
        if rs:
            try:
                rs.request_stop()
                print("[close] reminder scheduler: флаг остановки установлен")
            except Exception:
                pass
        try:
            db.close()
        except Exception:
            pass
        _remove_session_db_files()

    def _on_close(_e=None):
        # flet 0.86: on_close срабатывает, когда WebSocket уже разорван и
        # page.session.connection is None — page.run_task() падает с
        # AttributeError: 'NoneType' object has no attribute 'loop'.
        # Событие всё равно диспатчится на живом цикле сервера, поэтому
        # планируем корутину очистки напрямую через loop.create_task().
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None:
            try:
                loop.create_task(on_close_async())
                return
            except Exception:
                pass
        _session_teardown_sync()

    page.on_close = _on_close

    # Обработка возврата в приложение (из фона)
    def _take_pending_notification_task():
        if not session.is_authenticated:
            return None
        try:
            from platform_caps import android_available
            if not android_available():
                return None
        except Exception:
            pass
        try:
            from jnius import autoclass
            ActivityThread = autoclass("android.app.ActivityThread")
            app = ActivityThread.currentApplication()
            if app is None:
                return None
            prefs = app.getApplicationContext().getSharedPreferences(
                "ordnung_notification", 0
            )
            task_id = int(prefs.getInt("pending_task_id", -1))
            if task_id > 0:
                prefs.edit().remove("pending_task_id").apply()
                return task_id
        except Exception as ex:
            print(f"[notification] launch handoff unavailable: {ex}")
        return None

    async def _open_notification_task_if_pending():
        await asyncio.sleep(0.45)
        task_id = _take_pending_notification_task()
        if task_id is None:
            return
        if page.route not in ("/tasks", "/"):
            await page.push_route("/tasks")
            await asyncio.sleep(0.35)
        refs = getattr(page, "_tasks_view_refs", None)
        open_details = refs.get("open_task_details") if refs else None
        if open_details:
            open_details(task_id)
        else:
            print(f"[notification] task details handler not ready: {task_id}")

    def on_resume(e):
        print("[app] resumed")
        
        # --- ПРОВЕРКА И ПЕРЕНОС ЗАДАЧ ---
        carry_enabled = (repo.get_setting("carry_over_singles", "1") or "1") == "1"
        if carry_enabled:
            try:
                repo.carry_over_uncompleted_singles()
            except Exception as ex:
                print(f"[resume] carry_over error: {ex}")
        # --------------------------------
                
        refs = getattr(page, "_tasks_view_refs", None)
        if refs and refs.get("refresh"):
            try:
                refs["refresh"]()
            except Exception as ex:
                print(f"[app] resume refresh error: {ex}")
        
        asyncio.create_task(_open_notification_task_if_pending())
    page.on_resume = on_resume

    # ============ Старт ============
    if session.is_authenticated:
        show_tasks()
        
    else:
        show_login()


if __name__ == "__main__":
    ft.run(main)