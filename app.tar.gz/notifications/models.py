# notifications/models.py
"""Модели напоминаний."""
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Reminder:
    """Напоминание о задаче."""
    id: int = 0
    task_id: int = 0
    task_text: str = ""
    fire_at: str = ""                # ISO 8601 UTC "YYYY-MM-DDTHH:MM:SS.ffffffZ"
    minutes_before: int = 15
    fired: bool = False
    fired_at: Optional[str] = None
    created_at: str = ""

    def fire_datetime(self) -> Optional[datetime]:
        try:
            s = self.fire_at.rstrip("Z")
            return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%f")
        except Exception:
            return None