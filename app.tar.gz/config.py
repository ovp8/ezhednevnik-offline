# config.py
# ВНИМАНИЕ: Web API Key не является секретом.
# Защита данных обеспечивается правилами Firestore (Security Rules).
import os

FIREBASE_API_KEY = "AIzaSyBOsq-tKbN7xyK67gLh_safU_ZmszFZc1w"
FIREBASE_PROJECT_ID = "daily-planner-e250c"

AUTH_SIGN_UP_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FIREBASE_API_KEY}"
AUTH_SIGN_IN_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FIREBASE_API_KEY}"
AUTH_REFRESH_URL = f"https://securetoken.googleapis.com/v1/token?key={FIREBASE_API_KEY}"

FIRESTORE_BASE = (
    f"https://firestore.googleapis.com/v1/projects/{FIREBASE_PROJECT_ID}"
    f"/databases/(default)/documents"
)

APP_NAME = "Ежедневник"
APP_SLOGAN = "задачи, синхронизация, офлайн"
# ============ Режим распространения ============
# False — обычная версия (пользователь может включить автосинхронизацию в настройках).
# True  — версия для распространения: автосинхронизация принудительно выключена,
#         пользователь не может её включить. Ручная синхронизация (🔄) работает.
# Переопределяется переменной окружения (для облачного хостинга):
#   DISTRIBUTION_MODE=False python iphone_server.py
DISTRIBUTION_MODE = os.getenv("DISTRIBUTION_MODE", "True").strip().lower() in (
    "1", "true", "yes", "on",
)