# db/db_persist.py
"""
Постоянное хранилище локальной БД в браузере (статическая WASM-сборка).

Проблема: в Pyodide файловая система — memfs в памяти. Перезагрузка
страницы (или офлайн-старт PWA) = пустая SQLite, и без сети список задач
пуст. Сессия при этом восстанавливается (auth_session в localStorage),
а данные — нет.

Решение: сериализуем ВСЕ таблицы SQLite в JSON и кладём в
SharedPreferences (на web это localStorage браузера — постоянное
хранилище, переживающее перезагрузку и офлайн). Ключ — db_snapshot_<uid>:
у каждого пользователя свой снапшот, чужие данные не подмешиваются.

Почему localStorage (через SharedPreferences), а не IndexedDB напрямую:
  * это уже проверенный канал приложения — так живёт auth_session,
    офлайн-восстановление сессии покрыто E2E;
  * синхронный Python-код без моста JS-промисов (Pyodide однопоточен,
    ошибка в промисе = тихая потеря данных);
  * объём: ~5 МБ на origin — это тысячи текстовых задач, реалистичный
    запас для ежедневника.

Гарантии целостности:
  * сохранение — через debounce (~1 c) после последней мутации, плюс
    flush при уходе страницы в фон (AppLifecycleState.HIDE);
  * при превышении лимита снапшот НЕ пишется (частичная запись
    невозможна: localStorage.set атомарен), данные остаются в Firestore;
  * при порче JSON снапшот игнорируется, приложение стартует пустым
    и подтягивает данные при первом онлайне.

Firestore остаётся источником истины: снапшот — это офлайн-кэш с
очередью изменений (sync_status pending_*), который синхронизация
выталкивает при появлении сети.
"""
import json
import time
import asyncio

SNAPSHOT_VERSION = 1
PREFS_PREFIX = "db_snapshot_"
# Консервативный лимит localStorage (~5 МБ на origin, делённый с
# auth_session и запасом движка). Превышение = отказ от записи, не падение.
MAX_SNAPSHOT_BYTES = 2_500_000
# Задержка debounce: мутации в пачке (full-pull на 100+ задач) схлопываются
# в одну запись localStorage.
DEBOUNCE_SECONDS = 1.0

# Порядок таблиц важен для диагностики; состав — вся схема LocalDB.
TABLES = ("tasks", "reminders", "templates", "detail_templates", "settings")


class BrowserDBStore:
    """Сохраняет/восстанавливает локальную БД в хранилище браузера.

    db          — LocalDB (экспорт/импорт таблиц);
    get_uid     — callable, текущий uid сессии ("" если не залогинен);
    prefs_get/prefs_set/prefs_remove — async-обёртки над SharedPreferences
                  (берутся из main.py, чтобы модуль не зависел от flet).
    """

    def __init__(self, db, get_uid, prefs_get, prefs_set, prefs_remove=None):
        self.db = db
        self._get_uid = get_uid
        self._prefs_get = prefs_get
        self._prefs_set = prefs_set
        self._prefs_remove = prefs_remove
        self._dirty = False
        self._saving = False
        self._warned_size = False
        self._last_bytes = 0

    # ---------- Ключ снапшота ----------

    def _key(self, uid: str = "") -> str:
        return PREFS_PREFIX + (uid or self._get_uid() or "anon")

    # ---------- Сохранение ----------

    def schedule_save(self):
        """Хук для LocalDB.on_change (синхронный контекст, не await).

        Ставит dirty-флаг и порождает одну debounce-задачу: пачка мутаций
        (например, full-pull) даёт одну запись localStorage.
        """
        self._dirty = True
        if self._saving:
            return
        self._saving = True
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._save_debounced())
        except Exception as ex:
            self._saving = False
            print(f"[persist] schedule error: {ex}")

    async def _save_debounced(self):
        try:
            while self._dirty:
                self._dirty = False
                await asyncio.sleep(DEBOUNCE_SECONDS)
                try:
                    await self.save_now()
                except Exception as ex:
                    print(f"[persist] save error: {type(ex).__name__}: {ex}")
        finally:
            self._saving = False

    async def save_now(self) -> bool:
        """Пишет снапшот текущего пользователя. False — записать не удалось."""
        uid = self._get_uid() or ""
        if not uid:
            return False  # не залогинен — снапшот не нужен
        snap = self.db.export_all()
        snap["uid"] = uid
        snap["saved_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        raw = json.dumps(snap, ensure_ascii=False, separators=(",", ":"))
        if len(raw.encode("utf-8")) > MAX_SNAPSHOT_BYTES:
            if not self._warned_size:
                self._warned_size = True
                print(f"[persist] snapshot {len(raw)} B > limit "
                      f"{MAX_SNAPSHOT_BYTES} B — запись пропущена "
                      f"(Firestore останется источником истины)")
            return False
        await self._prefs_set(self._key(uid), raw)
        self._last_bytes = len(raw)
        n_tasks = len((snap.get("tables") or {}).get("tasks") or [])
        print(f"[persist] saved snapshot: {n_tasks} tasks, "
              f"{len(raw)} bytes, uid={uid[:8]}…")
        return True

    # ---------- Восстановление ----------

    async def restore(self, uid: str = "") -> int:
        """Заливает снапшот пользователя в пустую (или чужую) SQLite.

        Возвращает число восстановленных строк. Чужой/битый снапшот
        игнорируется — база остаётся пустой до первого online-pull.
        """
        uid = uid or self._get_uid() or ""
        if not uid:
            return 0
        raw = await self._prefs_get(self._key(uid))
        if not raw:
            print("[persist] no snapshot for this uid — чистый старт")
            return 0
        try:
            snap = raw if isinstance(raw, dict) else json.loads(raw)
        except (json.JSONDecodeError, TypeError) as ex:
            print(f"[persist] snapshot corrupt, ignored: {ex}")
            return 0
        if not isinstance(snap, dict) or not isinstance(snap.get("tables"), dict):
            print("[persist] snapshot format unknown — ignored")
            return 0
        snap_uid = snap.get("uid") or ""
        if snap_uid and snap_uid != uid:
            print(f"[persist] snapshot uid mismatch ({snap_uid[:8]}… != {uid[:8]}…) — skip")
            return 0
        n = self.db.import_all(snap["tables"])
        n_tasks = len(snap["tables"].get("tasks") or [])
        print(f"[persist] restored snapshot: {n} rows ({n_tasks} tasks), "
              f"saved_at={snap.get('saved_at')}")
        return n

    # ---------- Очистка ----------

    async def clear(self, uid: str = "") -> None:
        """Удаляет снапшот (logout на общем устройстве)."""
        uid = uid or self._get_uid() or ""
        if not uid or self._prefs_remove is None:
            return
        try:
            await self._prefs_remove(self._key(uid))
            print(f"[persist] snapshot cleared (uid={uid[:8]}…)")
        except Exception as ex:
            print(f"[persist] clear error: {ex}")
