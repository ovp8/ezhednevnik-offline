# db/local_db.py
"""
Локальная SQLite-база. Источник истины для UI.

Работает офлайн. Все изменения помечаются sync_status.
Синхронизация — отдельным модулем sync/sync_manager.py.

Потокобезопасность:
  * соединение создаётся с check_same_thread=False;
  * все публичные методы защищены RLock.
Это позволяет безопасно вызывать sync_once из executor'а
(asyncio.run_in_executor), не блокируя главный поток Flet.

Категории задач: 'personal' | 'work' | 'other' (default: 'personal').
"""
import os
import json
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Optional

# Состав снапшота (db/db_persist.py). Порядок не важен, полнота — важна.
SNAPSHOT_TABLES = ("tasks", "reminders", "templates", "detail_templates", "settings")

CATEGORY_DEFAULT = "personal"
CATEGORY_VALUES = ("personal", "work", "other")


def _now_iso() -> str:
    """Текущее время UTC в ISO 8601 с миллисекундами."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class LocalDB:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ensure_dir()
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.RLock()
        # Хук «БД изменилась» (WASM: автосохранение снапшота в localStorage).
        # Вызывается ПОСЛЕ каждого commit'а в мутациях. На CPython остаётся
        # None — файловый диск персистентен сам по себе.
        self.on_change = None

    def _ensure_dir(self):
        d = os.path.dirname(self.db_path)
        if d and not os.path.exists(d):
            os.makedirs(d, exist_ok=True)

    @property
    def conn(self) -> sqlite3.Connection:
        with self._lock:
            if self._conn is None:
                self._conn = sqlite3.connect(
                    self.db_path,
                    check_same_thread=False,
                )
                self._conn.row_factory = sqlite3.Row
                self._conn.execute("PRAGMA foreign_keys = ON")
                self._conn.execute("PRAGMA journal_mode = WAL")
            return self._conn

    def close(self):
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    # ---------- Схема ----------

    def init_schema(self):
        with self._lock:
            c = self.conn
            c.executescript("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    priority INTEGER DEFAULT 3,
                    datetime TEXT,
                    task TEXT NOT NULL,
                    status INTEGER DEFAULT 0,
                    details TEXT DEFAULT '[]',
                    repeat TEXT DEFAULT NULL,
                    note TEXT,
                    category TEXT DEFAULT 'personal'
                );

                CREATE TABLE IF NOT EXISTS reminders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER,
                    task_text TEXT,
                    fire_at TEXT,
                    minutes_before INTEGER DEFAULT 15,
                    fired INTEGER DEFAULT 0,
                    fired_at TEXT,
                    created_at TEXT
                );                

                CREATE TABLE IF NOT EXISTS templates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task TEXT UNIQUE
                );

                CREATE TABLE IF NOT EXISTS detail_templates (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT UNIQUE
                );

                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );
            """)
            c.commit()
            self._migrate_sync_fields()

    def _column_exists(self, table: str, column: str) -> bool:
        cur = self.conn.execute(f"PRAGMA table_info({table})")
        return any(row["name"] == column for row in cur.fetchall())

    def _migrate_sync_fields(self):
        c = self.conn
        # Поля синхронизации
        sync_cols = [
            ("cloud_id", "TEXT"),
            ("user_id", "TEXT"),
            ("sync_status", "TEXT DEFAULT 'pending_create'"),
            ("updated_at", "TEXT"),
            ("cloud_updated_at", "TEXT"),
            ("is_deleted", "INTEGER DEFAULT 0"),
            ("carried_over", "INTEGER DEFAULT 0"),
        ]
        for name, typ in sync_cols:
            if not self._column_exists("tasks", name):
                c.execute(f"ALTER TABLE tasks ADD COLUMN {name} {typ}")

        # Поле категории
        if not self._column_exists("tasks", "category"):
            c.execute(f"ALTER TABLE tasks ADD COLUMN category TEXT DEFAULT '{CATEGORY_DEFAULT}'")
            # Существующие задачи — в «личные» (не трогаем user_id, если NULL — оставим как есть)
            c.execute(f"UPDATE tasks SET category = ? WHERE category IS NULL", (CATEGORY_DEFAULT,))

        c.execute("CREATE INDEX IF NOT EXISTS idx_tasks_sync_status ON tasks(sync_status)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_tasks_cloud_id ON tasks(cloud_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_tasks_datetime ON tasks(datetime)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_reminders_fire_at ON reminders(fire_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_reminders_task ON reminders(task_id)")
        # Поля для расширенного напоминания (kind + repeat)
        reminder_cols = [
            ("kind", "TEXT DEFAULT 'before'"),
            ("repeat_interval_min", "INTEGER DEFAULT 0"),
            ("repeat_max", "INTEGER DEFAULT 0"),
            ("repeat_count", "INTEGER DEFAULT 0"),
        ]
        for name, typ in reminder_cols:
            if not self._column_exists("reminders", name):
                c.execute(f"ALTER TABLE reminders ADD COLUMN {name} {typ}")
        c.execute("CREATE INDEX IF NOT EXISTS idx_reminders_kind ON reminders(kind)")

        c.commit()

        # Поле для отслеживания «спрашивали ли пользователя о просрочке»
        if not self._column_exists("tasks", "last_warned_at"):
            c.execute("ALTER TABLE tasks ADD COLUMN last_warned_at TEXT")
        c.execute("CREATE INDEX IF NOT EXISTS idx_tasks_last_warned ON tasks(last_warned_at)")

    # ---------- Задачи ----------

    def add_task(self, task: str, priority: int = 3,
                 datetime_str: Optional[str] = None,
                 details: Optional[list] = None,
                 repeat: Optional[dict] = None,
                 note: Optional[str] = None,
                 user_id: Optional[str] = None,
                 category: Optional[str] = None) -> int:
        cat = category if category in CATEGORY_VALUES else CATEGORY_DEFAULT
        with self._lock:
            cur = self.conn.execute(
                """INSERT INTO tasks (priority, datetime, task, status, details, repeat, note,
                                       sync_status, updated_at, is_deleted, user_id, category)
                   VALUES (?, ?, ?, 0, ?, ?, ?, 'pending_create', ?, 0, ?, ?)""",
                (priority, datetime_str, task,
                 json.dumps(details or [], ensure_ascii=False),
                 json.dumps(repeat, ensure_ascii=False) if repeat else None,
                 note, _now_iso(), user_id, cat),
            )
            self.conn.commit()
            self._touch()
            return cur.lastrowid

    def get_task(self, task_id: int) -> Optional[dict]:
        with self._lock:
            cur = self.conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
            row = cur.fetchone()
            return self._task_row_to_dict(row) if row else None

    def get_tasks_for_day(self, date_str: str, user_id: Optional[str] = None,
                          category: Optional[str] = None) -> list:
        """Задачи на конкретный день. Фильтр по user_id и (опционально) по категории."""
        with self._lock:
            query = "SELECT * FROM tasks WHERE is_deleted = 0 AND datetime LIKE ?"
            params = [f"{date_str}%"]
            if user_id:
                query += " AND user_id = ?"
                params.append(user_id)
            if category and category in CATEGORY_VALUES:
                query += " AND category = ?"
                params.append(category)
            query += " ORDER BY priority DESC, datetime ASC"
            cur = self.conn.execute(query, params)
            return [self._task_row_to_dict(r) for r in cur.fetchall()]

    def get_all_tasks(self, user_id: Optional[str] = None,
                      category: Optional[str] = None) -> list:
        with self._lock:
            query = "SELECT * FROM tasks WHERE is_deleted = 0"
            params = []
            if user_id:
                query += " AND user_id = ?"
                params.append(user_id)
            if category and category in CATEGORY_VALUES:
                query += " AND category = ?"
                params.append(category)
            query += " ORDER BY datetime DESC"
            cur = self.conn.execute(query, params)
            return [self._task_row_to_dict(r) for r in cur.fetchall()]

    def update_task(self, task_id: int, **fields) -> bool:
        with self._lock:
            task = self.get_task(task_id)
            if not task:
                return False
            allowed = {"priority", "datetime", "task", "status", "details",
                       "repeat", "note", "category", "carried_over"}
            updates = {k: v for k, v in fields.items() if k in allowed}
            if not updates:
                return False
            if "category" in updates and updates["category"] not in CATEGORY_VALUES:
                updates["category"] = CATEGORY_DEFAULT
            if "details" in updates and not isinstance(updates["details"], str):
                updates["details"] = json.dumps(updates["details"], ensure_ascii=False)
            if "repeat" in updates and updates["repeat"] is not None \
                    and not isinstance(updates["repeat"], str):
                updates["repeat"] = json.dumps(updates["repeat"], ensure_ascii=False)
            updates["updated_at"] = _now_iso()
            updates["sync_status"] = "pending_update" if task.get("cloud_id") else "pending_create"

            set_clause = ", ".join(f"{k} = ?" for k in updates)
            values = list(updates.values()) + [task_id]
            self.conn.execute(f"UPDATE tasks SET {set_clause} WHERE id = ?", values)
            self.conn.commit()
            self._touch()
            return True

    def delete_task(self, task_id: int) -> bool:
        with self._lock:
            task = self.get_task(task_id)
            if not task:
                return False
            if not task.get("cloud_id"):
                self.conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            else:
                self.conn.execute(
                    """UPDATE tasks SET is_deleted = 1, sync_status = 'pending_delete',
                                        updated_at = ? WHERE id = ?""",
                    (_now_iso(), task_id),
                )
            self.conn.commit()
            self._touch()
            return True

    # ---------- Sync-помощники ----------

    def get_unsynced_tasks(self) -> list:
        with self._lock:
            cur = self.conn.execute(
                """SELECT * FROM tasks
                   WHERE sync_status IN ('pending_create','pending_update','pending_delete')
                   ORDER BY updated_at ASC"""
            )
            return [self._task_row_to_dict(r) for r in cur.fetchall()]

    def mark_task_synced(self, task_id: int, cloud_id: str,
                         cloud_updated_at: Optional[str] = None):
        with self._lock:
            if cloud_updated_at is None:
                self.conn.execute(
                    """UPDATE tasks SET cloud_id = ?, sync_status = 'synced',
                                        cloud_updated_at = COALESCE(updated_at, cloud_updated_at)
                       WHERE id = ?""",
                    (cloud_id, task_id),
                )
            else:
                self.conn.execute(
                    """UPDATE tasks SET cloud_id = ?, sync_status = 'synced',
                                        cloud_updated_at = ?
                       WHERE id = ?""",
                    (cloud_id, cloud_updated_at, task_id),
                )
            self.conn.commit()
            self._touch()

    def mark_task_remotely_deleted(self, task_id: int):
        with self._lock:
            self.conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
            self.conn.commit()
            self._touch()

    def find_by_cloud_id(self, cloud_id: str) -> Optional[dict]:
        with self._lock:
            cur = self.conn.execute("SELECT * FROM tasks WHERE cloud_id = ?", (cloud_id,))
            row = cur.fetchone()
            return self._task_row_to_dict(row) if row else None

    def insert_remote_task(self, data: dict) -> int:
        with self._lock:
            details = data.get("details")
            if isinstance(details, (list, dict)):
                details = json.dumps(details, ensure_ascii=False)
            repeat = data.get("repeat")
            if isinstance(repeat, (list, dict)):
                repeat = json.dumps(repeat, ensure_ascii=False)

            category = data.get("category")
            if category not in CATEGORY_VALUES:
                category = CATEGORY_DEFAULT

            cur = self.conn.execute(
                """INSERT INTO tasks
                   (priority, datetime, task, status, details, repeat, note,
                    sync_status, updated_at, cloud_updated_at, cloud_id, user_id,
                    is_deleted, category)
                   VALUES (?, ?, ?, ?, ?, ?, ?, 'synced', ?, ?, ?, ?, 0, ?)""",
                (
                    data.get("priority", 3),
                    data.get("datetime"),
                    data.get("task", ""),
                    data.get("status", 0),
                    details or "[]",
                    repeat,
                    data.get("note"),
                    data.get("updated_at"),
                    data.get("cloud_updated_at"),
                    data.get("cloud_id"),
                    data.get("user_id"),
                    category,
                ),
            )
            self.conn.commit()
            self._touch()
            return cur.lastrowid

    def apply_remote_update(self, task_id: int, data: dict):
        with self._lock:
            details = data.get("details")
            if isinstance(details, (list, dict)):
                details = json.dumps(details, ensure_ascii=False)
            repeat = data.get("repeat")
            if isinstance(repeat, (list, dict)):
                repeat = json.dumps(repeat, ensure_ascii=False)

            category = data.get("category")
            if category not in CATEGORY_VALUES:
                category = CATEGORY_DEFAULT

            self.conn.execute(
                """UPDATE tasks SET
                    priority = ?, datetime = ?, task = ?, status = ?,
                    details = ?, repeat = ?, note = ?, category = ?,
                    sync_status = 'synced',
                    updated_at = ?, cloud_updated_at = ?, is_deleted = 0
                   WHERE id = ?""",
                (
                    data.get("priority", 3),
                    data.get("datetime"),
                    data.get("task", ""),
                    data.get("status", 0),
                    details or "[]",
                    repeat,
                    data.get("note"),
                    category,
                    data.get("updated_at"),
                    data.get("cloud_updated_at"),
                    task_id,
                ),
            )
            self.conn.commit()
            self._touch()

    def get_tasks_for_user(self, user_id: str,
                           category: Optional[str] = None) -> list:
        with self._lock:
            query = "SELECT * FROM tasks WHERE is_deleted = 0 AND user_id = ?"
            params = [user_id]
            if category and category in CATEGORY_VALUES:
                query += " AND category = ?"
                params.append(category)
            query += " ORDER BY datetime DESC"
            cur = self.conn.execute(query, params)
            return [self._task_row_to_dict(r) for r in cur.fetchall()]

    def clear_all_tasks(self):
        with self._lock:
            self.conn.execute("DELETE FROM tasks")
            self.conn.commit()
            self._touch()

    # ---------- Settings ----------
    def delete_tasks_before(self, before_date: str, user_id: Optional[str] = None,
                            category: Optional[str] = None,
                            only_done: bool = False) -> int:
        """
        Удаляет задачи с datetime < before_date (строка 'YYYY-MM-DD').
        only_done=True — только status=1.
        Задачи с cloud_id — soft delete (pending_delete), без cloud_id — физически.
        Возвращает количество затронутых задач.
        """
        with self._lock:
            bound = f"{before_date} 23:59"
            query = "SELECT id, cloud_id FROM tasks WHERE is_deleted = 0 AND datetime < ?"
            params = [bound]
            if user_id:
                query += " AND user_id = ?"
                params.append(user_id)
            if category in CATEGORY_VALUES:
                query += " AND category = ?"
                params.append(category)
            if only_done:
                query += " AND status = 1"
            cur = self.conn.execute(query, params)
            rows = cur.fetchall()
            for r in rows:
                tid = r["id"]
                cid = r["cloud_id"] if "cloud_id" in r.keys() else None
                if cid:
                    self.conn.execute(
                        """UPDATE tasks SET is_deleted = 1,
                                            sync_status = 'pending_delete',
                                            updated_at = ?
                           WHERE id = ?""",
                        (_now_iso(), tid),
                    )
                else:
                    self.conn.execute("DELETE FROM tasks WHERE id = ?", (tid,))
            self.conn.commit()
            self._touch()
            return len(rows)

    def get_setting(self, key: str, default=None):
        with self._lock:
            cur = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cur.fetchone()
            return row["value"] if row else default

    def set_setting(self, key: str, value: str):
        with self._lock:
            self.conn.execute(
                """INSERT INTO settings (key, value) VALUES (?, ?)
                   ON CONFLICT(key) DO UPDATE SET value = excluded.value""",
                (key, value),
            )
            self.conn.commit()
            self._touch()

    # ---------- Экспорт/импорт снапшота (WASM-персистентность) ----------

    def _touch(self):
        """Сигнализирует об изменении данных (после commit'а)."""
        cb = self.on_change
        if cb is not None:
            try:
                cb()
            except Exception as ex:
                print(f"[db] on_change error: {ex}")

    def export_all(self) -> dict:
        """Все таблицы → JSON-совместимый словарь (для localStorage)."""
        with self._lock:
            tables = {}
            for name in SNAPSHOT_TABLES:
                cur = self.conn.execute(f"SELECT * FROM {name}")
                cols = [d[0] for d in cur.description]
                tables[name] = [dict(zip(cols, r)) for r in cur.fetchall()]
            return {"version": 1, "tables": tables}

    def import_all(self, tables: dict) -> int:
        """Очищает и заново заливает таблицы из снапшота.

        id сохраняются как есть — reminders.task_id и локальные ссылки
        остаются валидными. Возвращает число вставленных строк.
        Битые строки/типы пропускаются без падения.
        """
        if not isinstance(tables, dict):
            return 0
        total = 0
        with self._lock:
            c = self.conn
            for name in SNAPSHOT_TABLES:
                rows = tables.get(name)
                if rows is None or not isinstance(rows, list):
                    continue  # таблицы нет в снапшоте (старая версия) — ок
                c.execute(f"DELETE FROM {name}")
                for row in rows:
                    if not isinstance(row, dict) or not row:
                        continue
                    cols = [k for k in row.keys()]
                    if not cols:
                        continue
                    ph = ", ".join("?" for _ in cols)
                    try:
                        c.execute(
                            f"INSERT OR REPLACE INTO {name} ({', '.join(cols)}) "
                            f"VALUES ({ph})",
                            [row[k] for k in cols],
                        )
                        total += 1
                    except (sqlite3.Error, TypeError) as ex:
                        print(f"[db] import row skipped ({name}): {ex}")
            c.commit()
        return total

    # ---------- Утилита ----------

    def _task_row_to_dict(self, row: sqlite3.Row) -> dict:
        d = dict(row)
        for field in ("details", "repeat"):
            if d.get(field):
                try:
                    d[field] = json.loads(d[field])
                except (TypeError, json.JSONDecodeError):
                    d[field] = [] if field == "details" else None
            else:
                d[field] = [] if field == "details" else None
        if d.get("category") not in CATEGORY_VALUES:
            d["category"] = CATEGORY_DEFAULT
        return d