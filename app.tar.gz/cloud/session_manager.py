# cloud/session_manager.py
"""
Управление пользовательской сессией Firebase Auth.

Два режима:
- Десктоп/Android (один пользователь на устройстве): токен хранится в файле
  (auth_session.json) рядом с БД — как раньше.
- Мультипользовательский сервер (Render/PWA, FLET_MULTIUSER=1): токен живёт
  ТОЛЬКО в памяти сессии и НЕ пишется на диск сервера. Файл на сервере общий
  для всех сессий — если бы мы туда писали, второй пользователь получал бы
  аккаунт первого (критичный баг). «Запомнить меня» на устройстве в этом
  режиме делает main.py через SharedPreferences браузера (localStorage).
"""
from typing import Optional
from cloud.firebase_auth import (
    sign_up, sign_in, refresh_id_token,
    FirebaseAuthError, auth_result_to_session,
)
from cloud.auth_storage import (
    save_auth, load_auth, clear_auth, is_token_expired,
    DEFAULT_AUTH_FILE,
)


class SessionManager:
    def __init__(self, auth_path: str = DEFAULT_AUTH_FILE, multiuser: bool = False):
        self.auth_path = auth_path
        self.multiuser = multiuser
        self._auth: Optional[dict] = None
        if not multiuser:
            self._load_from_disk()

    # ---------- Сохранение/восстановление (для «запомнить меня» на устройстве) ----------

    def export_state(self) -> Optional[dict]:
        """Копия состояния для сохранения на УСТРОЙСТВЕ (SharedPreferences)."""
        return dict(self._auth) if self._auth else None

    def restore(self, state: Optional[dict]) -> bool:
        """Загружает состояние, сохранённое на устройстве. Без записи на диск."""
        if not state or not state.get("idToken") or not state.get("uid"):
            return False
        self._auth = {
            "uid": state.get("uid") or "",
            "email": state.get("email") or "",
            "idToken": state.get("idToken") or "",
            "refreshToken": state.get("refreshToken") or "",
            "expiresAt": int(state.get("expiresAt") or 0),
        }
        return True

    # ---------- Состояние ----------

    @property
    def is_authenticated(self) -> bool:
        return self._auth is not None and bool(self._auth.get("idToken"))

    @property
    def uid(self) -> Optional[str]:
        return self._auth.get("uid") if self._auth else None

    @property
    def email(self) -> Optional[str]:
        return self._auth.get("email") if self._auth else None

    @property
    def id_token(self) -> Optional[str]:
        return self._auth.get("idToken") if self._auth else None

    # ---------- Внутренние ----------

    def _load_from_disk(self):
        self._auth = load_auth(self.auth_path)

    def _persist(self):
        # В multiuser-режиме на диск сервера НЕ пишем: файл общий для всех
        # сессий, это приводило к утечке аккаунтов между устройствами.
        if self.multiuser:
            return
        if self._auth:
            save_auth(self._auth, self.auth_path)
        else:
            clear_auth(self.auth_path)

    def ensure_fresh_token(self) -> str:
        """
        Возвращает актуальный idToken, обновляя его при необходимости.
        Бросает FirebaseAuthError, если refreshToken тоже протух.
        """
        if not self._auth:
            raise FirebaseAuthError("NO_SESSION", "Пользователь не авторизован")

        if not is_token_expired(self._auth):
            return self._auth["idToken"]

        # Обновляем
        refreshed = refresh_id_token(self._auth["refreshToken"])
        self._auth["idToken"] = refreshed["idToken"]
        self._auth["refreshToken"] = refreshed["refreshToken"]
        # Firebase выдаёт новый expiresIn
        import time
        self._auth["expiresAt"] = int(time.time()) + int(refreshed.get("expiresIn", 3600))
        self._persist()
        return self._auth["idToken"]

    # ---------- Публичный API ----------

    def login(self, email: str, password: str) -> dict:
        result = sign_in(email, password)
        self._auth = auth_result_to_session(result)
        self._persist()
        return self._auth

    def register(self, email: str, password: str) -> dict:
        result = sign_up(email, password)
        self._auth = auth_result_to_session(result)
        self._persist()
        return self._auth

    def logout(self):
        self._auth = None
        self._persist()