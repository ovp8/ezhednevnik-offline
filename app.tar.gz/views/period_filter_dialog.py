"""Расширенный фильтр задач по периоду и типу."""
import calendar
from datetime import date
from ui.components import elevated_button
import flet as ft
from ui.calendar_picker import show_task_date_picker


def _add_months(day: date, months: int) -> date:
    index = day.year * 12 + day.month - 1 + months
    year, month_zero = divmod(index, 12)
    month = month_zero + 1
    return date(year, month, min(day.day, calendar.monthrange(year, month)[1]))


def show_period_filter(page, repo, palette, initial_filter, on_apply):
    today = date.today()
    initial_filter = initial_filter or {}
    state = {
        "start": initial_filter.get("start", today),
        "end": initial_filter.get("end", today),
        "kind": initial_filter.get("kind", "all"),
        "high_priority": bool(initial_filter.get("high_priority", False)),
        "hide_daily": bool(initial_filter.get("hide_daily", False)),
    }
    if state["start"] > state["end"]:
        state["start"], state["end"] = state["end"], state["start"]

    start_label = ft.Text("", color=palette["text"], size=14)
    end_label = ft.Text("", color=palette["text"], size=14)
    dialog_ref = {"dialog": None}
    kind_checks = {}
    flag_checks = {}

    def update_labels():
        start_label.value = state["start"].strftime("%d.%m.%Y")
        end_label.value = state["end"].strftime("%d.%m.%Y")

    def refresh_dialog():
        update_labels()
        for key, row in kind_checks.items():
            row.controls[0].value = state["kind"] == key
        for key, row in flag_checks.items():
            row.controls[0].value = bool(state[key])
        if dialog_ref["dialog"] is not None:
            dialog_ref["dialog"].update()

    def set_preset(kind):
        now = date.today()
        if kind == "forward":
            state["start"], state["end"] = now, _add_months(now, 1)
        elif kind == "back":
            state["start"], state["end"] = _add_months(now, -1), now
        else:
            state["start"], state["end"] = date(now.year, 1, 1), date(now.year, 12, 31)
        refresh_dialog()

    def choose_date(which):
        def selected(day):
            state[which] = day
            if state["start"] > state["end"]:
                if which == "start":
                    state["end"] = day
                else:
                    state["start"] = day
            refresh_dialog()

        show_task_date_picker(
            page=page, repo=repo, palette=palette,
            initial_date=state[which], on_select=selected,
        )

    def kind_changed(kind):
        def changed(value):
            if value:
                state["kind"] = kind
            elif state["kind"] == kind:
                state["kind"] = "all"
            refresh_dialog()
        return changed

    def flag_changed(key):
        def changed(value):
            state[key] = bool(value)
            refresh_dialog()
        return changed

    def checkbox(label, value, on_toggle):
        check = ft.Checkbox(
            value=value,
            on_change=lambda e: on_toggle(bool(e.control.value)),
            active_color=palette["accent"],
        )

        def toggle_from_label(e):
            check.value = not bool(check.value)
            on_toggle(bool(check.value))

        return ft.Row(
            controls=[
                check,
                ft.Container(
                    content=ft.Text(
                        label,
                        color=palette["text"],
                        size=14,
                        max_lines=2,
                    ),
                    expand=True,
                    on_click=toggle_from_label,
                    ink=True,
                ),
            ],
            spacing=4,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def build_content():
        update_labels()
        kind = state["kind"]
        kind_checks.update({
            "all": checkbox("Все", kind == "all", kind_changed("all")),
            "repeat": checkbox("С повтором", kind == "repeat", kind_changed("repeat")),
            "one_time": checkbox("Разовые", kind == "one_time", kind_changed("one_time")),
            "hourly": checkbox("Ежечасные", kind == "hourly", kind_changed("hourly")),
        })
        flag_checks.update({
            "high_priority": checkbox("С высоким приоритетом (4–5)", state["high_priority"], flag_changed("high_priority")),
            "hide_daily": checkbox("Не показывать ежедневные", state["hide_daily"], flag_changed("hide_daily")),
        })

        # --- НОВЫЙ БЛОК ДЛЯ ГЛЯНЦЕВЫХ ЧИПСОВ ---
        def _glossy_chip(label, on_click):
            return ft.Container(
                content=ft.Text(label, size=11, color="#FFFFFF", weight=ft.FontWeight.W_600, no_wrap=True),
                padding=ft.Padding.only(left=10, top=8, right=10, bottom=8),
                border_radius=12,
                gradient=ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#4A6B8A", "#1C2D41"],
                ),
                border=ft.Border.all(1, "#FFFFFF"),
                on_click=on_click,
                ink=True,
            )
        # --------------------------------------

        return ft.Column(
            tight=True,
            spacing=4,
            controls=[
                ft.Text("Период", color=palette["text_muted"], size=12),
                ft.Column(
                    controls=[
                        ft.TextButton(
                            content=ft.Row(
                                controls=[ft.Text("С:", color=palette["text_muted"]), start_label],
                                tight=True,
                                spacing=5,
                            ),
                            on_click=lambda e: choose_date("start"),
                        ),
                        ft.TextButton(
                            content=ft.Row(
                                controls=[ft.Text("По:", color=palette["text_muted"]), end_label],
                                tight=True,
                                spacing=5,
                            ),
                            on_click=lambda e: choose_date("end"),
                        ),
                    ],
                    spacing=0,
                    tight=True,
                ),
                ft.Container(height=4),
                # --- ЗАМЕНИЛИ TEXTBUTTON НА ЧИПСЫ ---
                ft.Row(
                    controls=[
                        _glossy_chip("Месяц вперёд", lambda e: set_preset("forward")),
                        _glossy_chip("Месяц назад", lambda e: set_preset("back")),
                        _glossy_chip("Год", lambda e: set_preset("year")),
                    ],
                    spacing=6,
                    wrap=True,
                    run_spacing=6,
                ),
                # -----------------------------------
                ft.Divider(color=palette["border"]),
                ft.Text("Тип задач", color=palette["text_muted"], size=12),
                *kind_checks.values(),
                *flag_checks.values(),
            ],
        )

    def apply():
        page.pop_dialog()
        on_apply(dict(state))

    page_width = page.width or 360
    dialog_width = max(180, min(420, page_width - 40))
    dialog_ref["dialog"] = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text("Показать за период", color=palette["text"], size=17),
        content=ft.Container(width=dialog_width, content=build_content()),
        content_padding=ft.Padding.only(left=8, top=6, right=8, bottom=6),
        inset_padding=ft.Padding.only(left=8, top=16, right=8, bottom=16),
        actions=[
            ft.Row(
                controls=[
                    elevated_button("Отмена", lambda e: page.pop_dialog(), palette, primary=False, expand=True),
                    ft.Container(width=10),
                    elevated_button("Показать", lambda e: apply(), palette, primary=True, expand=True),
                ],
                spacing=0,
            ),
        ],
        actions_padding=ft.Padding.only(left=16, top=0, right=16, bottom=10),
    )
    page.show_dialog(dialog_ref["dialog"])