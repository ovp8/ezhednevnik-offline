# views/task_edit_view.py
"""Экран редактирования задачи (создание + редактирование + копия).

Детализация: точечное добавление строк без пересоздания списка.
Фокус на новое поле — явным tf.focus(), прокрутка — через scroll_to (async),
при недоступности — auto_scroll без выключения.
"""
import asyncio
from datetime import datetime, timezone, timedelta
import flet as ft
from ui.components import elevated_button, snack, divider, styled_field
from ui.calendar_picker import show_task_date_picker
from views.reminders_dialog import open_reminders_dialog
from db.local_db import CATEGORY_DEFAULT, CATEGORY_VALUES


CATEGORY_LABELS = {
    "personal": "Личные",
    "work": "Работа",
    "other": "Прочие",
}

WEEKDAY_NAMES = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
MONTH_NAMES = ["января", "февраля", "марта", "апреля", "мая", "июня",
               "июля", "августа", "сентября", "октября", "ноября", "декабря"]

REPEAT_OPTIONS = [
    ("none", "Не повторять", ft.Icons.BLOCK),
    ("hourly", "Ежечасно", ft.Icons.ACCESS_TIME),
    ("daily", "Ежедневно", ft.Icons.CALENDAR_TODAY),
    ("days", "По дням недели", ft.Icons.VIEW_WEEK),
    ("monthly", "Ежемесячно", ft.Icons.CALENDAR_MONTH),
    ("yearly", "Ежегодно", ft.Icons.EVENT),
]


def _get_date_from_picker(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone().date()
    if hasattr(value, "year"):
        return value
    return None


def _parse_display_date(text):
    try:
        text = (text or "").strip()
        if not text:
            return None
        for fmt in ("%d-%m-%y", "%d-%m-%Y", "%d.%m.%y", "%d.%m.%Y"):
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
        return None
    except Exception:
        return None


def _display_to_db(text):
    d = _parse_display_date(text)
    return d.strftime("%Y-%m-%d") if d else ""


def _db_to_display(text):
    try:
        return datetime.strptime(text, "%Y-%m-%d").strftime("%d-%m-%y")
    except Exception:
        return ""


def _split_minutes(total: int):
    """Разбивает общее количество минут на (дни, часы, минуты)."""
    total = max(0, int(total or 0))
    d = total // 1440
    h = (total % 1440) // 60
    m = total % 60
    return d, h, m


def build_task_edit_view(
    page: ft.Page,
    repo,
    palette: dict,
    task_id=None,
    copy_from_id=None,
    initial_category: str = CATEGORY_DEFAULT,
    initial_date=None,
    on_save=None,
    on_back=None,
    font_scale: float = 1.0,
):

    def _sz(base: int) -> int:
        return max(10, int(base * font_scale))

    is_edit = task_id is not None
    source_id = task_id if is_edit else copy_from_id

    if source_id:
        task = repo.get_task(source_id) or {}
    else:
        task = {}

    initial_text = task.get("task") or ""
    initial_note = task.get("note") or ""
    initial_priority = int(task.get("priority") or 3)
    initial_details = list(task.get("details") or [])
    initial_repeat = task.get("repeat") if isinstance(task.get("repeat"), dict) else None

    cat0 = task.get("category") or initial_category or CATEGORY_DEFAULT
    categories_enabled = (repo.get_setting("categories_enabled", "1") or "1") == "1"
    if cat0 not in CATEGORY_VALUES:
        cat0 = CATEGORY_DEFAULT
    if not is_edit and not categories_enabled:
        cat0 = CATEGORY_DEFAULT

    if is_edit:
        dt = task.get("datetime") or ""
        if " " in dt:
            initial_date_str = _db_to_display(dt.split(" ")[0])
            initial_time = dt.split(" ")[-1]
        else:
            now = datetime.now()
            initial_date_str = now.strftime("%d-%m-%y")
            initial_time = now.strftime("%H:%M")
    else:
        now = datetime.now()
        if initial_date is not None and hasattr(initial_date, "strftime"):
            initial_date_str = initial_date.strftime("%d-%m-%y")
        else:
            initial_date_str = now.strftime("%d-%m-%y")
        initial_time = now.strftime("%H:%M")

    norm_details = []
    for d in initial_details:
        if isinstance(d, dict):
            norm_details.append({
                "text": d.get("text", ""),
                "done": bool(d.get("done", False)),
                "duration": d.get("duration", "") or "",
            })
        else:
            norm_details.append({"text": str(d), "done": False, "duration": ""})

    # Загружаем существующие настройки напоминания (если правим)
    existing_reminder_cfg = {"before": None, "at_time": False,
                             "repeat": False, "repeat_interval": 5, "repeat_max": 4}
    if is_edit:
        try:
            existing_reminder_cfg = repo.get_reminder_config(task_id)
        except Exception as ex:
            print(f"[edit] get_reminder_config: {ex}")
    else:
        # Для новой задачи читаем дефолт из настроек
        try:
            at_time_default = (repo.get_setting("at_time_default", "0") or "0") == "1"
            existing_reminder_cfg["at_time"] = at_time_default
        except Exception as ex:
            print(f"[edit] at_time_default read error: {ex}")

    state = {
        "priority": initial_priority,
        "category": cat0,
        "details": norm_details,
        "repeat_type": "none",
        "daily_interval": 1,
        "weekdays": set(),
        "monthly_day": 1,
        "yearly_month": 1,
        "yearly_day": 1,
        "hourly_interval": 1,
        "reminders_cfg": dict(existing_reminder_cfg),
    }
    body_ref = {"ctrl": None}
    
    def suspend_form_focus():
        fields = []
        seen = set()
        def visit(control):
            if control is None or id(control) in seen:
                return
            seen.add(id(control))
            if isinstance(control, ft.TextField):
                fields.append((control, control.can_request_focus))
                control.can_request_focus = False
            for child in getattr(control, "controls", []) or []:
                visit(child)
            visit(getattr(control, "content", None))
        visit(body_ref.get("ctrl"))
        try:
            page.update()
        except Exception:
            pass
        return fields

    async def restore_form_focus(fields):
        await asyncio.sleep(0.25)
        for field, previous in fields:
            try:
                field.can_request_focus = previous
            except Exception:
                pass
        try:
            page.update()
        except Exception:
            pass

    def schedule_focus_restore(fields):
        asyncio.create_task(restore_form_focus(fields))

    def show_editor_dialog(dialog):
        fields = suspend_form_focus()
        old_dismiss = getattr(dialog, "on_dismiss", None)
        def dismissed(e):
            if old_dismiss:
                old_dismiss(e)
            schedule_focus_restore(fields)
        dialog.on_dismiss = dismissed
        page.show_dialog(dialog)

    if initial_repeat and isinstance(initial_repeat, dict):
        rtype = initial_repeat.get("type")
        if rtype == "daily":
            state["repeat_type"] = "daily"
            state["daily_interval"] = int(initial_repeat.get("interval", 1) or 1)
        elif rtype == "days":
            state["repeat_type"] = "days"
            state["weekdays"] = set(initial_repeat.get("days", []) or [])
        elif rtype == "monthly":
            state["repeat_type"] = "monthly"
            state["monthly_day"] = int(initial_repeat.get("day", 1) or 1)
        elif rtype == "yearly":
            state["repeat_type"] = "yearly"
            state["yearly_month"] = int(initial_repeat.get("month", 1) or 1)
            state["yearly_day"] = int(initial_repeat.get("day", 1) or 1)
        elif rtype == "hourly":
            state["repeat_type"] = "hourly"
            state["hourly_interval"] = int(initial_repeat.get("interval", 1) or 1)

    # ============================================================
    #  ОБЩИЕ ПОЛЯ
    # ============================================================
    task_field = styled_field("Задание", palette, multiline=True)
    task_field.value = initial_text
    task_field.min_lines = 2
    task_field.max_lines = 2

    note_field = styled_field("Примечание", palette, multiline=True)
    note_field.value = initial_note
    note_field.min_lines = 1
    note_field.max_lines = 1
    try:
        note_field.content_padding = ft.Padding.only(left=10, top=8, right=10, bottom=8)
    except Exception:
        pass

    # Значения хранятся в state — визуально показываем кастомные «кнопки»
    date_state = {"value": initial_date_str}
    time_state = {"value": initial_time}

    date_display = ft.Text(initial_date_str, color=palette["text"], size=_sz(14),
                           weight=ft.FontWeight.W_500)
    time_display = ft.Text(initial_time, color=palette["text"], size=_sz(14),
                           weight=ft.FontWeight.W_500)

    # ---------- Категория ----------
    category_row = ft.Row(spacing=6, visible=categories_enabled)
    category_controls = {}

    def set_category(val):
        state["category"] = val
        for key, ctrl in category_controls.items():
            selected = (key == val)
            if selected:
                ctrl.gradient = ft.LinearGradient(
                    begin=ft.Alignment.TOP_CENTER,
                    end=ft.Alignment.BOTTOM_CENTER,
                    colors=["#4A6B8A", "#1C2D41"],
                )
                ctrl.border = ft.Border.all(1, "#FFFFFF")
                ctrl.shadow = ft.BoxShadow(blur_radius=6, color="#000000AA", offset=ft.Offset(0, 2))
                ctrl.bgcolor = None
                ctrl.content.color = "#FFFFFF"
            else:
                ctrl.gradient = None
                ctrl.bgcolor = palette["surface2"]
                ctrl.border = None
                ctrl.shadow = None
                ctrl.content.color = palette["text"]
        try:
            category_row.update()
        except Exception:
            page.update()

    for key in ("personal", "work", "other"):
        chip = ft.Container(
            content=ft.Text(CATEGORY_LABELS[key], size=_sz(12),
                            max_lines=1, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS,
                            text_align=ft.TextAlign.CENTER,
                            weight=ft.FontWeight.W_500, color=palette["text"]),
            expand=True,
            padding=ft.Padding.only(left=6, top=8, right=6, bottom=8),
            border_radius=20,
            on_click=lambda e, k=key: set_category(k),
            ink=True,
            animate=ft.Animation(150, ft.AnimationCurve.EASE_OUT), # Плавность
        )
        category_controls[key] = chip
        category_row.controls.append(chip)
    set_category(cat0)
    category_section = ft.Column(
        controls=[
            ft.Text("Категория", color=palette["text_muted"], size=_sz(12), visible=categories_enabled),
            ft.Container(height=6),
            category_row,
            ft.Container(height=20),
        ],
        spacing=0,
        visible=categories_enabled,
    )

    # ---------- Приоритет ----------
    priority_row = ft.Row(spacing=6, alignment=ft.MainAxisAlignment.START)

    def set_priority(val):
        state["priority"] = val
        priority_row.controls.clear()
        for i in range(1, 6):
            selected = i <= val
            color = palette["priority"][i - 1] if selected else palette["surface2"]
            star = ft.Container(
                content=ft.Text("★",
                                color="#FFFFFF" if selected else palette["text_muted"],
                                size=_sz(20)),
                width=48, height=48,
                bgcolor=color,
                border_radius=12,
                alignment=ft.Alignment.CENTER,
                on_click=lambda e, v=i: set_priority(v),
                ink=True,
            )
            priority_row.controls.append(star)
        try:
            priority_row.update()
        except Exception:
            page.update()

    set_priority(initial_priority)

    # ---------- Дата / Время ----------
    def pick_date(e):
        def date_picked(chosen_date):
            date_state["value"] = chosen_date.strftime("%d-%m-%y")
            date_display.value = date_state["value"]
            page.update()

        fields = suspend_form_focus()
        show_task_date_picker(
            page=page,
            repo=repo,
            palette=palette,
            initial_date=_parse_display_date(date_state["value"]) or datetime.now(),
            on_select=date_picked,
            on_dismiss=lambda: schedule_focus_restore(fields),
        )

    def pick_time(e):
        def time_picked(ev):
            try:
                t = ev.control.value
                t = t.time() if hasattr(t, "time") else t
                time_state["value"] = t.strftime("%H:%M")
                time_display.value = time_state["value"]
            except Exception:
                pass
            try:
                time_display.update()
            except Exception:
                page.update()

        # Начальное значение пикера — текущее (не 00:00)
        import datetime as _dt2
        init_t = _dt2.time(0, 0)
        try:
            hh, mm = (time_state["value"] or "00:00").split(":")[:2]
            init_t = _dt2.time(int(hh), int(mm))
        except Exception:
            init_t = _dt2.time(0, 0)

        try:
            tp = ft.TimePicker(on_change=time_picked,
                               value=init_t,
                               hour_format=ft.TimePickerHourFormat.H24,
                               entry_mode=ft.TimePickerEntryMode.DIAL)
        except Exception:
            tp = ft.TimePicker(on_change=time_picked, value=init_t,
                               hour_format=ft.TimePickerHourFormat.H24)
        fields = suspend_form_focus()
        tp.on_dismiss = lambda ev: schedule_focus_restore(fields)
        page.overlay.append(tp)
        tp.open = True
        page.update()

    # ============================================================
    #  ПОВТОР
    # ============================================================
    repeat_icon = ft.Icon(ft.Icons.REPEAT, color=palette["text_muted"], size=_sz(18))
    repeat_label = ft.Text("Не повторять", color=palette["text"], size=_sz(14),
                           weight=ft.FontWeight.W_500)

    def _current_repeat_title():
        for key, label, _ in REPEAT_OPTIONS:
            if key == state["repeat_type"]:
                return label
        return "Не повторять"

    def open_repeat_dialog(e=None):
        rows = ft.Column(spacing=0)

        def make_pick(key):
            def pick(e):
                state["repeat_type"] = key
                page.pop_dialog()
                refresh_repeat_ui()
            return pick

        for key, label, icon in REPEAT_OPTIONS:
            selected = (state["repeat_type"] == key)
            row = ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Icon(icon, size=_sz(20),
                                color=palette["accent"] if selected else palette["text_muted"]),
                        ft.Container(width=12),
                        ft.Text(label, size=_sz(15), color=palette["text"],
                                weight=ft.FontWeight.W_500 if selected else ft.FontWeight.W_400),
                        ft.Container(expand=True),
                        ft.Icon(ft.Icons.CHECK, size=_sz(18), color=palette["accent"],
                                visible=selected),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.only(left=14, top=14, right=14, bottom=14),
                bgcolor=palette["surface2"] if selected else palette["surface"],
                on_click=make_pick(key),
                ink=True,
            )
            rows.controls.append(row)

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Тип повтора", color=palette["text"], size=16),
            content=ft.Container(content=rows, width=320),
        )
        show_editor_dialog(dlg)

    repeat_selector = ft.Container(
        content=ft.Row(
            controls=[
                repeat_icon,
                ft.Container(width=10),
                repeat_label,
                ft.Container(expand=True),
                ft.Icon(ft.Icons.ARROW_DROP_DOWN,
                        color=palette["text_muted"], size=_sz(20)),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=14, top=14, right=14, bottom=14),
        bgcolor=palette["surface2"],
        border=ft.Border.all(1, palette["border"]),
        border_radius=12,
        on_click=open_repeat_dialog,
        ink=True,
    )

    params_holder = ft.Container(content=None)

    def build_daily_section():
        f = styled_field("Каждые N дней", palette)
        f.value = str(state["daily_interval"])
        f.keyboard_type = ft.KeyboardType.NUMBER

        def on_change(e):
            try:
                state["daily_interval"] = max(1, int((f.value or "1").strip()))
            except Exception:
                state["daily_interval"] = 1

        f.on_change = on_change
        return f

    def build_days_section():
        row = ft.Row(spacing=6, wrap=True)

        def toggle(idx):
            if idx in state["weekdays"]:
                state["weekdays"].discard(idx)
            else:
                state["weekdays"].add(idx)
            refresh_repeat_ui()

        for i, name in enumerate(WEEKDAY_NAMES):
            selected = i in state["weekdays"]
            chip = ft.Container(
                content=ft.Text(name, size=_sz(13), weight=ft.FontWeight.W_500,
                                color="#FFFFFF" if selected else palette["text"]),
                width=48, height=42,
                alignment=ft.Alignment.CENTER,
                bgcolor=palette["accent"] if selected else palette["surface2"],
                border_radius=10,
                on_click=lambda e, idx=i: toggle(idx),
                ink=True,
            )
            row.controls.append(chip)
        return row

    def pick_monthly_day(e):
        def picked(ev):
            d = _get_date_from_picker(ev.control.value)
            if d:
                state["monthly_day"] = d.day
                refresh_repeat_ui()

        try:
            init = datetime.now().replace(day=min(state["monthly_day"], 28))
        except Exception:
            init = datetime.now()
        dp = ft.DatePicker(on_change=picked, value=init)
        try:
            dp.locale = ft.Locale("ru")
        except Exception:
            pass
        fields = suspend_form_focus()
        dp.on_dismiss = lambda ev: schedule_focus_restore(fields)
        page.overlay.append(dp)
        dp.open = True
        page.update()

    def build_monthly_section():
        label = ft.Text(f"{state['monthly_day']}-го числа",
                        color=palette["text"], size=_sz(14),
                        weight=ft.FontWeight.W_500)
        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Icon(ft.Icons.CALENDAR_MONTH,
                            color=palette["text_muted"], size=_sz(18)),
                    ft.Container(width=10),
                    label,
                    ft.Container(expand=True),
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN,
                            color=palette["text_muted"], size=_sz(20)),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=14, top=14, right=14, bottom=14),
            bgcolor=palette["surface2"],
            border=ft.Border.all(1, palette["border"]),
            border_radius=12,
            on_click=pick_monthly_day,
            ink=True,
        )

    def _yearly_text():
        m = MONTH_NAMES[max(0, min(11, state["yearly_month"] - 1))]
        return f"{state['yearly_day']} {m}"

    def pick_yearly_day(e):
        def picked(ev):
            d = _get_date_from_picker(ev.control.value)
            if d:
                state["yearly_month"] = d.month
                state["yearly_day"] = d.day
                refresh_repeat_ui()

        try:
            init = datetime.now().replace(month=state["yearly_month"],
                                           day=min(state["yearly_day"], 28))
        except Exception:
            init = datetime.now()
        dp = ft.DatePicker(on_change=picked, value=init)
        try:
            dp.locale = ft.Locale("ru")
        except Exception:
            pass
        fields = suspend_form_focus()
        dp.on_dismiss = lambda ev: schedule_focus_restore(fields)
        page.overlay.append(dp)
        dp.open = True
        page.update()

    def build_yearly_section():
        label = ft.Text(_yearly_text(), color=palette["text"], size=_sz(14),
                        weight=ft.FontWeight.W_500)
        return ft.Container(
            content=ft.Row(
                controls=[
                    ft.Icon(ft.Icons.EVENT, color=palette["text_muted"], size=_sz(18)),
                    ft.Container(width=10),
                    label,
                    ft.Container(expand=True),
                    ft.Icon(ft.Icons.ARROW_DROP_DOWN,
                            color=palette["text_muted"], size=_sz(20)),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=14, top=14, right=14, bottom=14),
            bgcolor=palette["surface2"],
            border=ft.Border.all(1, palette["border"]),
            border_radius=12,
            on_click=pick_yearly_day,
            ink=True,
        )

    def build_hourly_section():
        f = styled_field("Каждые N часов", palette)
        f.value = str(state["hourly_interval"])
        f.keyboard_type = ft.KeyboardType.NUMBER

        def on_change(e):
            try:
                state["hourly_interval"] = max(1, int((f.value or "1").strip()))
            except Exception:
                state["hourly_interval"] = 1

        f.on_change = on_change
        return f

    def refresh_repeat_ui():
        repeat_label.value = _current_repeat_title()
        key = state["repeat_type"]
        if key == "daily":
            params_holder.content = build_daily_section()
        elif key == "days":
            params_holder.content = build_days_section()
        elif key == "monthly":
            params_holder.content = build_monthly_section()
        elif key == "yearly":
            params_holder.content = build_yearly_section()
        elif key == "hourly":
            params_holder.content = build_hourly_section()
        else:
            params_holder.content = None
        try:
            params_holder.update()
            repeat_label.update()
        except Exception:
            page.update()

    refresh_repeat_ui()

    # ============================================================
    #  ДЕТАЛИЗАЦИЯ
    # ============================================================
    details_rows_holder = ft.Column(spacing=8)
    clear_all_btn_ref = {"btn": None}

    def pick_detail_duration(idx, label_ctrl):
        def picked(ev):
            try:
                t = ev.control.value
                t = t.time() if hasattr(t, "time") else t
                val = t.strftime("%H:%M")
            except Exception:
                val = "00:00"
            state["details"][idx]["duration"] = val
            label_ctrl.value = val
            label_ctrl.color = palette["text"]
            try:
                label_ctrl.update()
            except Exception:
                page.update()

        # Начальное значение для пикера — 00:00 (или сохранённое в детали)
        import datetime as _dt
        init_time = _dt.time(0, 0)
        cur = (state["details"][idx].get("duration") or "").strip()
        if cur and ":" in cur:
            try:
                hh, mm = cur.split(":")[:2]
                init_time = _dt.time(int(hh), int(mm))
            except Exception:
                init_time = _dt.time(0, 0)

        try:
            tp = ft.TimePicker(
                on_change=picked,
                value=init_time,
                hour_format=ft.TimePickerHourFormat.H24,
                entry_mode=ft.TimePickerEntryMode.DIAL,
            )
        except Exception:
            tp = ft.TimePicker(on_change=picked, value=init_time,
                               hour_format=ft.TimePickerHourFormat.H24)
        fields = suspend_form_focus()
        tp.on_dismiss = lambda ev: schedule_focus_restore(fields)
        page.overlay.append(tp)
        tp.open = True
        page.update()

    def create_detail_row(idx, d):
        text_val = d.get("text", "")
        duration_val = d.get("duration", "") or ""

        tf = styled_field("Деталь", palette, multiline=True)
        tf.value = text_val
        tf.min_lines = 1
        tf.max_lines = 1
        try:
            tf.content_padding = ft.Padding.only(left=10, top=8, right=10, bottom=8)
        except Exception:
            pass

        def make_text_handler(i):
            def on_change(e):
                state["details"][i]["text"] = e.control.value or ""
            return on_change
        tf.on_change = make_text_handler(idx)

        dur_label = ft.Text(
            duration_val if duration_val else "00:00",
            size=_sz(13),
            color=palette["text"] if duration_val else palette["text_muted"],
        )

        duration_btn = ft.Container(
            content=ft.Row(
                controls=[
                    ft.Text("⏱️", size=_sz(14)),
                    ft.Container(width=4),
                    dur_label,
                ],
                spacing=0, tight=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            padding=ft.Padding.only(left=10, top=10, right=10, bottom=10),
            bgcolor=palette["surface2"],
            border_radius=10,
            on_click=lambda e, i=idx, lc=dur_label: pick_detail_duration(i, lc),
            ink=True,
            tooltip="Длительность",
        )

        def make_delete_row(i):
            def rm(e):
                state["details"].pop(i)
                refresh_details()
                try:
                    page.update()
                except Exception:
                    pass
            return rm

        delete_row_btn = ft.Container(
            content=ft.Icon(ft.Icons.CLOSE, color=palette["text_muted"], size=_sz(18)),
            width=40, height=40,
            border_radius=20,
            alignment=ft.Alignment.CENTER,
            on_click=make_delete_row(idx),
            ink=True,
            tooltip="Удалить строку",
        )

        return ft.Row(
            controls=[
                ft.Container(content=tf, expand=True),
                ft.Container(width=8),
                duration_btn,
                ft.Container(width=4),
                delete_row_btn,
            ],
            spacing=0,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def refresh_details():
        details_rows_holder.controls.clear()
        for idx, d in enumerate(state["details"]):
            details_rows_holder.controls.append(create_detail_row(idx, d))
        cb = clear_all_btn_ref.get("btn")
        if cb is not None:
            cb.visible = bool(state["details"])

    async def _focus_and_scroll_to_last():
        await asyncio.sleep(0.12)

        try:
            last_row = details_rows_holder.controls[-1]
            tf = last_row.controls[0].content
            await tf.focus()
            print("[detail] focus ok")
        except Exception as ex:
            print(f"[detail] focus fail: {ex}")
            return

        await asyncio.sleep(0.2)

        body_ctrl = body_ref.get("ctrl")
        if body_ctrl is None:
            print("[detail] body_ref None")
            return

        try:
            await body_ctrl.scroll_to(offset=-1, duration=300)
            print("[detail] scroll_to(offset=-1) ok")
            return
        except Exception as ex:
            print(f"[detail] scroll_to(offset=-1) fail: {ex}")

        try:
            await body_ctrl.scroll_to(delta=2000, duration=300)
            print("[detail] scroll_to(delta) ok")
            return
        except Exception as ex:
            print(f"[detail] scroll_to(delta) fail: {ex}")

        try:
            body_ctrl.auto_scroll = True
            page.update()
            print("[detail] auto_scroll=True (не выключаем)")
        except Exception as ex:
            print(f"[detail] auto_scroll fail: {ex}")

    def add_detail_row(e):
        body_ctrl = body_ref.get("ctrl")
        if body_ctrl is not None:
            try:
                body_ctrl.auto_scroll = False
            except Exception:
                pass

        state["details"].append({"text": "", "done": False, "duration": ""})
        new_idx = len(state["details"]) - 1
        new_row = create_detail_row(new_idx, state["details"][-1])
        details_rows_holder.controls.append(new_row)

        cb = clear_all_btn_ref.get("btn")
        if cb is not None:
            cb.visible = True

        try:
            page.update()
        except Exception:
            pass

        try:
            page.run_task(_focus_and_scroll_to_last)
        except Exception as ex:
            print(f"[detail] run_task fail: {ex}")

    def clear_all_details(e):
        if not state["details"]:
            return

        def do_yes(ev):
            page.pop_dialog()
            state["details"] = []
            refresh_details()
            try:
                page.update()
            except Exception:
                pass

        def do_no(ev):
            page.pop_dialog()

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Удалить всю детализацию?",
                          color=palette["text"], size=_sz(15)),
            content=ft.Text("Нельзя отменить.",
                            color=palette["text"], size=_sz(13)),
            actions=[
                ft.Row(
                    controls=[
                        elevated_button("Удалить", do_yes, palette,
                                        danger=True, expand=True),
                        ft.Container(width=10),
                        elevated_button("Отмена", do_no, palette, expand=True),
                    ],
                    spacing=0,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        show_editor_dialog(dlg)

    from ui.components import elevated_button # Убедись, что импортирован

    add_detail_btn = elevated_button(
        "+ Добавить детализацию", 
        add_detail_row, 
        palette, 
        primary=False
    )

    clear_all_btn = ft.Container(
        content=ft.Icon(ft.Icons.CLOSE, color=palette["danger"], size=22),
        width=44, height=44,
        border_radius=22,
        bgcolor=palette["surface2"],
        alignment=ft.Alignment.CENTER,
        on_click=clear_all_details,
        ink=True,
        tooltip="Удалить всю детализацию",
        visible=False,
    )
    clear_all_btn_ref["btn"] = clear_all_btn

    refresh_details()

    # ============================================================
    #  НАПОМИНАНИЕ  (кнопка-строка → полноэкранный диалог)
    # ============================================================
    reminder_summary = ft.Text(
        "", color=palette["text_muted"], size=_sz(13),
        max_lines=1, overflow=ft.TextOverflow.ELLIPSIS, expand=True,
    )
    reminder_icon = ft.Text("🔔", size=16)

    def _reminders_summary(cfg: dict) -> str:
        parts = []
        bv = cfg.get("before")
        if bv:
            bv = int(bv)
            if bv < 60:
                parts.append(f"за {bv} мин")
            elif bv < 1440:
                h = bv // 60
                m = bv % 60
                parts.append(f"за {h} ч" + (f" {m} мин" if m else ""))
            else:
                parts.append(f"за {bv // 1440} д")
        if cfg.get("at_time"):
            parts.append("в момент")
        if not parts:
            return "Не напоминать"
        text = " • ".join(parts)
        if cfg.get("repeat"):
            text += f" • повтор {cfg['repeat_interval']}×{cfg['repeat_max']}"
        return text

    def refresh_reminder_summary():
        reminder_summary.value = _reminders_summary(state["reminders_cfg"])
        try:
            reminder_summary.update()
        except Exception:
            page.update()

    def open_reminders(e=None):
        def handle_save(new_cfg):
            state["reminders_cfg"] = new_cfg
            refresh_reminder_summary()
        fields = suspend_form_focus()
        open_reminders_dialog(
            page, palette, state["reminders_cfg"], handle_save,
            on_close=lambda: schedule_focus_restore(fields),
        )

    reminder_row = ft.Container(
        content=ft.Row(
            controls=[
                reminder_icon,
                ft.Container(width=10),
                reminder_summary,
                ft.Icon(ft.Icons.ARROW_DROP_DOWN,
                        color=palette["text_muted"], size=_sz(20)),
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=14, top=14, right=14, bottom=14),
        bgcolor=palette["surface2"],
        border=ft.Border.all(1, palette["border"]),
        border_radius=12,
        on_click=open_reminders,
        ink=True,
    )
    refresh_reminder_summary()

    # ============================================================
    #  СОХРАНЕНИЕ
    # ============================================================
    def collect_repeat():
        rv = state["repeat_type"]
        if rv == "none":
            return None
        if rv == "daily":
            return {"type": "daily", "interval": int(state["daily_interval"] or 1)}
        if rv == "days":
            days = sorted(state["weekdays"])
            if not days:
                return None
            return {"type": "days", "days": days}
        if rv == "monthly":
            return {"type": "monthly", "day": state["monthly_day"]}
        if rv == "yearly":
            return {"type": "yearly",
                    "month": state["yearly_month"],
                    "day": state["yearly_day"]}
        if rv == "hourly":
            return {"type": "hourly", "interval": int(state["hourly_interval"] or 1)}
        return None

    def _parse_dt_for_check(dt_str: str):
        try:
            return datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
        except Exception:
            return None

    def _check_reminder_warning(dt_str: str):
        cfg = state["reminders_cfg"]
        if not (cfg.get("before") or cfg.get("at_time")):
            return None
        task_dt = _parse_dt_for_check(dt_str)
        if task_dt is None:
            return None
        now = datetime.now()
        if cfg.get("before"):
            fire_dt = task_dt - timedelta(minutes=int(cfg["before"]))
            if fire_dt <= now:
                mins = cfg["before"]
                return (
                    f"Напоминание «за {mins} мин» не будет создано — "
                    f"это время уже прошло.\n\n"
                    f"Сохранить задачу без напоминания или исправить время?"
                )
        if cfg.get("at_time"):
            if task_dt <= now:
                return (
                    "Напоминание «в момент события» не будет создано — "
                    "время задачи уже прошло.\n\n"
                    "Сохранить задачу без напоминания или исправить время?"
                )
        return None

    def _do_save_actual(text, dt_str, note, repeat, details, category,
                        skip_reminder):
        if is_edit:
            repo.update_task(
                task_id, task=text, priority=state["priority"],
                datetime=dt_str, details=details, repeat=repeat, note=note,
                category=category,
            )
            saved_task_id = task_id
        else:
            saved_task_id = repo.add_task(
                task=text, priority=state["priority"],
                datetime_str=dt_str, details=details, repeat=repeat, note=note,
                category=category,
            )

        cfg = state["reminders_cfg"]
        try:
            if skip_reminder or not (cfg.get("before") or cfg.get("at_time")):
                repo.clear_reminder(saved_task_id)
            else:
                st = repo.set_reminders(
                    saved_task_id,
                    before_min=cfg.get("before"),
                    at_time=bool(cfg.get("at_time")),
                    repeat=bool(cfg.get("repeat")),
                    repeat_interval=int(cfg.get("repeat_interval") or 5),
                    repeat_max=int(cfg.get("repeat_max") or 4),
                )
                if st.get("before_requested") and not st.get("before_set"):
                    print("[edit] WARN before not set: past time")
                elif st.get("at_time_requested") and not st.get("at_time_set"):
                    print("[edit] WARN at_time not set: past time")
        except Exception as ex:
            print(f"[edit] reminder save error: {ex}")

        if on_save:
            on_save()

    def _show_warning_dialog(msg, dt_str, text, note, repeat, details, category):
        def do_save_anyway(ev):
            page.pop_dialog()
            _do_save_actual(
                text=text, dt_str=dt_str, note=note, repeat=repeat,
                details=details, category=category, skip_reminder=True,
            )

        def do_fix(ev):
            page.pop_dialog()
            try:
                open_reminders(None)
            except Exception as ex:
                print(f"[edit] open reminders after warn error: {ex}")

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Напоминание не будет создано",
                          color=palette["danger"], size=_sz(15)),
            content=ft.Text(msg, color=palette["text"], size=_sz(13)),
            actions=[
                ft.Row(
                    controls=[
                        ft.Container(
                            content=ft.Text("Исправить", color="#FFFFFF",
                                            size=_sz(14), weight=ft.FontWeight.W_600),
                            padding=ft.Padding.only(left=14, top=10, right=14, bottom=10),
                            bgcolor=palette["accent"], border_radius=12,
                            on_click=do_fix, ink=True, expand=True,
                            alignment=ft.Alignment.CENTER,
                        ),
                        ft.Container(width=10),
                        ft.Container(
                            content=ft.Text("Сохранить без", color=palette["text"],
                                            size=_sz(14), weight=ft.FontWeight.W_600),
                            padding=ft.Padding.only(left=14, top=10, right=14, bottom=10),
                            bgcolor=palette["surface2"], border_radius=12,
                            on_click=do_save_anyway, ink=True, expand=True,
                            alignment=ft.Alignment.CENTER,
                        ),
                    ],
                    spacing=0,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        show_editor_dialog(dlg)

    def do_save(e):
        reminder_warning = None   # ← инициализируем сразу, чтобы не было NameError
        body_ctrl = body_ref.get("ctrl")
        if body_ctrl is not None:
            try:
                body_ctrl.auto_scroll = False
            except Exception:
                pass

        text = (task_field.value or "").strip()
        if not text:
            snack(page, "Введите текст задачи", palette, error=True)
            return
        db_date = _display_to_db(date_state["value"] or "")
        if not db_date:
            snack(page, "Неверная дата", palette, error=True)
            return
        time_s = (time_state["value"] or "").strip() or "09:00"
        dt_str = f"{db_date} {time_s}"
        note = (note_field.value or "").strip() or None
        repeat = collect_repeat()

        details = []
        for d in state["details"]:
            t = (d.get("text") or "").strip()
            if not t:
                continue
            duration = (d.get("duration") or "").strip() or "00:00"
            details.append({
                "text": t,
                "done": bool(d.get("done", False)),
                "duration": duration,
            })
        category = state["category"]

        warning = _check_reminder_warning(dt_str)
        if warning:
            _show_warning_dialog(
                warning, dt_str, text=text, note=note, repeat=repeat,
                details=details, category=category,
            )
            return

        _do_save_actual(
            text=text, dt_str=dt_str, note=note, repeat=repeat,
            details=details, category=category, skip_reminder=False,
        )

        async def _show_snack_later():
            import asyncio
            await asyncio.sleep(0.35)
            try:
                if reminder_warning:
                    _msg = reminder_warning
                    _color = palette["danger"]
                else:
                    _msg = "Сохранено"
                    _color = palette["success"]
                page.snack_bar = ft.SnackBar(
                    content=ft.Text(_msg, color="#FFFFFF"),
                    bgcolor=_color,
                    duration=2500,
                )
                page.snack_bar.open = True
                page.update()
                print(f"[edit] snack shown: {_msg}")
            except Exception as ex:
                print(f"[edit] snack error: {ex}")

        try:
            page.run_task(_show_snack_later)
        except Exception as ex:
            print(f"[edit] run_task snack error: {ex}")
    def do_delete(e):
        if not is_edit:
            return

        def on_yes(ev):
            page.pop_dialog()
            repo.delete_task(task_id)
            if on_save:
                on_save()

        def on_no(ev):
            page.pop_dialog()

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Удалить задачу?", color=palette["text"], size=16),
            content=ft.Text("Это действие нельзя отменить.", color=palette["text"]),
            actions=[
                ft.Row(
                    controls=[
                        elevated_button("Удалить", on_yes, palette,
                                        danger=True, expand=True),
                        ft.Container(width=10),
                        elevated_button("Отмена", on_no, palette, expand=True),
                    ],
                    spacing=0,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        show_editor_dialog(dlg)

    # ---------- Шапка ----------
    def go_back(e):
        if on_back:
            on_back()

    title_text = "Редактирование" if is_edit else (
        "Копия задачи" if copy_from_id else "Новая задача"
    )

    # Кнопка удаления (красный глянец)
    delete_btn_style = ft.Container(
        content=ft.Icon(ft.Icons.DELETE_OUTLINE, color="#FFFFFF", size=20),
        width=44, height=44,
        border_radius=22,
        border=ft.Border.all(2, "#FFFFFF"),
        gradient=ft.LinearGradient(
            begin=ft.Alignment.TOP_CENTER,
            end=ft.Alignment.BOTTOM_CENTER,
            colors=["#8A3A3A", "#4A1C1C"],
        ),
        alignment=ft.Alignment.CENTER,
        on_click=do_delete if is_edit else None,
        visible=is_edit,
        ink=True,
        shadow=ft.BoxShadow(blur_radius=6, color="#000000AA", offset=ft.Offset(0, 3)),
    )

    # Кнопка сохранения (синий глянец, как FAB)
    save_btn_style = ft.Container(
        content=ft.Icon(ft.Icons.CHECK, color="#FFFFFF", size=24),
        width=44, height=44,
        border_radius=22,
        border=ft.Border.all(2, "#FFFFFF"),
        gradient=ft.LinearGradient(
            begin=ft.Alignment.TOP_CENTER,
            end=ft.Alignment.BOTTOM_CENTER,
            colors=["#4A6B8A", "#1C2D41"],
        ),
        alignment=ft.Alignment.CENTER,
        on_click=do_save,
        ink=True,
        shadow=ft.BoxShadow(blur_radius=6, color="#000000AA", offset=ft.Offset(0, 3)),
    )

    header = ft.Container(
        content=ft.Row(
            controls=[
                ft.IconButton(
                    icon=ft.Icons.ARROW_BACK,
                    icon_color=palette["text"],
                    on_click=go_back,
                ),
                ft.Container(
                    content=ft.Text(title_text, color=palette["text"],
                                    size=18, weight=ft.FontWeight.W_600,
                                    max_lines=1, overflow=ft.TextOverflow.ELLIPSIS),
                    expand=True,
                ),
                ft.Container(width=8), # Отступ перед кнопками
                save_btn_style,
            ],
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        padding=ft.Padding.only(left=4, top=4, right=4, bottom=4),
        bgcolor=palette["surface"],
    )

    # ---------- Тело ----------
    body = ft.Column(
        controls=[
            ft.Text("Категория", color=palette["text_muted"], size=_sz(12), visible=categories_enabled),
            ft.Container(height=6),
            category_row,
            ft.Container(height=20),

            ft.Text("Приоритет", color=palette["text_muted"], size=_sz(12)),
            ft.Container(height=6),
            priority_row,
            ft.Container(height=20),

            ft.Row(
                controls=[
                    ft.Container(
                        content=ft.Row(
                            controls=[
                                ft.Icon(ft.Icons.CALENDAR_MONTH, size=_sz(18),
                                        color=palette["text_muted"]),
                                ft.Container(width=10),
                                date_display,
                            ],
                            spacing=0, tight=True,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        padding=ft.Padding.only(left=14, top=12, right=14, bottom=12),
                        bgcolor=palette["surface2"],
                        border=ft.Border.all(1, palette["border"]),
                        border_radius=12,
                        on_click=pick_date,
                        ink=True,
                        expand=True,
                    ),
                    ft.Container(width=8),
                    ft.Container(
                        content=ft.Row(
                            controls=[
                                ft.Icon(ft.Icons.SCHEDULE, size=_sz(18),
                                        color=palette["text_muted"]),
                                ft.Container(width=10),
                                time_display,
                            ],
                            spacing=0, tight=True,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        ),
                        padding=ft.Padding.only(left=14, top=12, right=14, bottom=12),
                        bgcolor=palette["surface2"],
                        border=ft.Border.all(1, palette["border"]),
                        border_radius=12,
                        on_click=pick_time,
                        ink=True,
                    ),
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            ft.Container(height=20),
            task_field,
            ft.Container(height=16),
            note_field,
            ft.Container(height=20),

            ft.Text("Повтор", color=palette["text_muted"], size=_sz(12)),
            ft.Container(height=6),
            repeat_selector,
            ft.Container(height=8),
            params_holder,

            ft.Container(height=20),
            ft.Text("Напоминание", color=palette["text_muted"], size=_sz(12)),
            ft.Container(height=6),
            reminder_row,

            ft.Container(height=20),

            ft.Row(
                controls=[
                    ft.Text("Детализация", color=palette["text_muted"], size=_sz(12)),
                    ft.Container(expand=True),
                    clear_all_btn,
                ],
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            ft.Container(height=6),

            details_rows_holder,
            ft.Container(height=10),
            add_detail_btn,
            ft.Container(height=30),
        ],
        spacing=0,
        scroll=ft.ScrollMode.AUTO,
        auto_scroll=False,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )
    body_ref["ctrl"] = body

    content_wrap = ft.Container(
        content=body,
        padding=ft.Padding.only(left=16, top=16, right=16, bottom=16),
        expand=True,
    )

    root = ft.Column(
        controls=[header, divider(palette), content_wrap],
        spacing=0,
        expand=True,
    )
    return root