# views/overdue_dialog.py
"""Диалог для просроченных повторяющихся задач.

Показывается один раз в 24 часа на задачу. Две кнопки:
  - Выполнено           → отметить выполненной + создать следующий экземпляр
  - Пропустить, перенести → оставить в истории, создать следующий экземпляр
"""
import flet as ft
from ui.components import elevated_button

def show_overdue_dialog(page, palette, task, on_resolve):
    """
    :param page: ft.Page
    :param palette: dict
    :param task: dict с полями id, task, datetime, repeat
    :param on_resolve: Callable(task_id, completed: bool) — вызывается при ответе
    """
    task_id = task["id"]
    task_text = task.get("task") or "(без названия)"
    dt_str = task.get("datetime") or ""

    def _fmt_dt(s):
        try:
            from datetime import datetime as _dt
            d = _dt.strptime(s, "%Y-%m-%d %H:%M")
            return d.strftime("%d.%m.%y %H:%M")
        except Exception:
            return s

    repeat = task.get("repeat") or {}
    rtype = repeat.get("type")
    type_label = {
        "hourly": "ежечасная",
        "daily": "ежедневная",
        "days": "по дням недели",
        "monthly": "ежемесячная",
        "yearly": "ежегодная",
    }.get(rtype, "повторяющаяся")

    def do_completed(ev):
        page.pop_dialog()
        try:
            on_resolve(task_id, True)
        except Exception as ex:
            print(f"[overdue] on_resolve(completed) error: {ex}")

    def do_skip(ev):
        page.pop_dialog()
        try:
            on_resolve(task_id, False)
        except Exception as ex:
            print(f"[overdue] on_resolve(skip) error: {ex}")

    dlg = ft.AlertDialog(
        modal=True,
        bgcolor=palette["surface"],
        title=ft.Text("Просроченная задача",
                      color=palette["warning"], size=16),
        content=ft.Column(
            controls=[
                ft.Text(task_text, color=palette["text"], size=15,
                        weight=ft.FontWeight.W_600, max_lines=3),
                ft.Container(height=8),
                ft.Text(f"Запланирована: {_fmt_dt(dt_str)}",
                        color=palette["text_muted"], size=12),
                ft.Text(f"Тип: {type_label}",
                        color=palette["text_muted"], size=12),
                ft.Container(height=8),
                ft.Text(
                    "Что делаем? Следующий экземпляр будет создан "
                    "в любом случае — вопрос только в статусе этой задачи.",
                    color=palette["text"], size=12, italic=True,
                ),
            ],
            spacing=2,
            tight=True,
        ),
        actions=[
            ft.Row(
                controls=[
                    elevated_button("Выполнено", do_completed, palette, primary=True, expand=True),
                    ft.Container(width=10),
                    elevated_button("Пропустить", do_skip, palette, primary=False, expand=True),
                ],
                spacing=0,
            ),
        ],
        actions_alignment=ft.MainAxisAlignment.CENTER,
    )
    page.show_dialog(dlg)