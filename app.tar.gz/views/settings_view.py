# views/settings_view.py
"""Полноценный экран настроек (ft.View)."""
import flet as ft
from ui.components import styled_field
from platform_caps import android_available

try:
    from config import DISTRIBUTION_MODE
except Exception:
    DISTRIBUTION_MODE = False

# ---- ключи настроек ----
KEY_CONFIRM_CHECKBOX = "confirm_checkbox"
KEY_SYNC_ENABLED = "sync_enabled"
KEY_SYNC_INTERVAL = "sync_interval"
KEY_COPY_REMINDER = "copy_reminder_on_repeat"
KEY_AT_TIME_DEFAULT = "at_time_default"
KEY_AUTHOR_LINE = "app_author_line"
KEY_FONT_SCALE = "ui_font_scale"
KEY_VISIBLE_ICONS = "ui_visible_icons"
KEY_CATEGORIES_ENABLED = "categories_enabled"
DEFAULT_VISIBLE_ICONS = "time,priority,note,repeat,subtasks,reminder"
KEY_CARRY_OVER_SINGLES = "carry_over_singles"


def _get_bool(repo, key: str, default: str = "0") -> bool:
    return (repo.get_setting(key, default) or default) == "1"

def _set_bool(repo, key: str, value: bool):
    repo.set_setting(key, "1" if value else "0")

def _check_notifications_enabled() -> bool:
    if not android_available():
        return False
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        app = ActivityThread.currentApplication()
        if app is None:
            return False
        ctx = app.getApplicationContext()
        Context = autoclass("android.content.Context")
        mgr = ctx.getSystemService(Context.NOTIFICATION_SERVICE)
        if mgr is None:
            return False
        return bool(mgr.areNotificationsEnabled())
    except Exception:
        return False

def _open_notification_settings(page):
    if not android_available():
        return
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        app = ActivityThread.currentApplication()
        if app is None:
            return
        ctx = app.getApplicationContext()
        Settings = autoclass("android.provider.Settings")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        Build = autoclass("android.os.Build$VERSION")
        JavaString = autoclass("java.lang.String")
        pkg = ctx.getPackageName()
        if Build.SDK_INT >= 26:
            try:
                intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, JavaString(pkg))
                intent.setData(Uri.parse("package:" + pkg))
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                return
            except Exception:
                pass
        intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.setData(Uri.parse("package:" + pkg))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    except Exception as ex:
        print(f"[settings] open notif settings error: {ex}")


def _check_full_screen_intent() -> bool:
    """Проверяет, разрешено ли приложению показывать полноэкранные уведомления."""
    if not android_available():
        return False
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        app = ActivityThread.currentApplication()
        if app is None:
            return False
        ctx = app.getApplicationContext()
        
        Build = autoclass("android.os.Build$VERSION")
        if Build.SDK_INT < 34: 
            # На Android 13 и ниже это разрешение выдается автоматически при наличии в манифесте
            return True
            
        Context = autoclass("android.content.Context")
        NotificationManager = autoclass("android.app.NotificationManager")
        nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE)
        
        # canUseFullScreenIntent() появился только в API 34
        return bool(nm.canUseFullScreenIntent())
    except Exception as ex:
        print(f"[settings] check full_screen error: {ex}")
        return False


def _open_full_screen_settings(page):
    """Открывает системный экран для разрешения полноэкранных уведомлений."""
    if not android_available():
        return
    try:
        from jnius import autoclass
        ActivityThread = autoclass("android.app.ActivityThread")
        app = ActivityThread.currentApplication()
        if app is None:
            return
        ctx = app.getApplicationContext()
        
        Settings = autoclass("android.provider.Settings")
        Intent = autoclass("android.content.Intent")
        Uri = autoclass("android.net.Uri")
        Build = autoclass("android.os.Build$VERSION")
        
        pkg = ctx.getPackageName()
        
        if Build.SDK_INT >= 34:
            intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
            intent.setData(Uri.parse("package:" + pkg))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            print("[settings] opened FULL_SCREEN_INTENT settings")
        else:
            # Для более старых версий открываем общие настройки приложения
            intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.setData(Uri.parse("package:" + pkg))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            
    except Exception as ex:
        print(f"[settings] open full_screen settings error: {ex}")


def build_settings_view(page, palette, repo, session, on_logout=None, on_back=None, on_save=None):
    state = {
        "confirm_checkbox": _get_bool(repo, KEY_CONFIRM_CHECKBOX, "1"),
        "sync_enabled": _get_bool(repo, KEY_SYNC_ENABLED, "0"),
        "sync_interval": str(repo.get_setting(KEY_SYNC_INTERVAL, "180") or "180"),
        "copy_reminder": _get_bool(repo, KEY_COPY_REMINDER, "1"),
        "at_time_default": _get_bool(repo, KEY_AT_TIME_DEFAULT, "0"),
        "font_scale": str(repo.get_setting(KEY_FONT_SCALE, "1.0") or "1.0"),
        "categories_enabled": _get_bool(repo, KEY_CATEGORIES_ENABLED, "1"),
        "visible_icons": set(
            (repo.get_setting(KEY_VISIBLE_ICONS, DEFAULT_VISIBLE_ICONS) or DEFAULT_VISIBLE_ICONS).split(",")
        ),
        "carry_over_singles": _get_bool(repo, KEY_CARRY_OVER_SINGLES, "1"),
    }

    initial_font_scale = state["font_scale"]
    initial_visible_icons = set(state["visible_icons"])
    initial_categories_enabled = state["categories_enabled"]

    try:
        from notifications.alarm_manager import (
            has_exact_alarm_permission,
            is_ignoring_battery_optimizations,
            request_exact_alarm_permission,
            request_ignore_battery_optimizations,
        )
    except Exception:
        has_exact_alarm_permission = lambda: False
        is_ignoring_battery_optimizations = lambda: False
        request_exact_alarm_permission = lambda: False
        request_ignore_battery_optimizations = lambda: False

    perm_state = {
        "exact": has_exact_alarm_permission(),
        "battery": is_ignoring_battery_optimizations(),
        "notif": _check_notifications_enabled(),
        "full_screen": _check_full_screen_intent(),
    }

    def _on_back(e=None):
        changes = {
            "font_scale": state["font_scale"] != initial_font_scale,
            "visible_icons": state["visible_icons"] != initial_visible_icons,
            "categories_enabled": state["categories_enabled"] != initial_categories_enabled,
        }
        if on_save and any(changes.values()):
            try:
                on_save(changes)
            except Exception as ex:
                print(f"[settings] on_save error: {ex}")
        if on_back:
            on_back()

    # ============================================================
    #  UI helpers
    # ============================================================
    def section_title(text):
        return ft.Container(
            content=ft.Text(text, color=palette["text_muted"], size=12, weight=ft.FontWeight.W_500),
            padding=ft.Padding.only(left=4, top=14, bottom=6),
        )

    def make_toggle(label, value: bool, on_change):
        st = {"value": bool(value)}
        box_visual = ft.Container(
            content=ft.Icon(ft.Icons.CHECK, color="#FFFFFF" if st["value"] else "transparent", size=16),
            width=26, height=26,
            bgcolor=palette["accent"] if st["value"] else "transparent",
            border=None if st["value"] else ft.Border.all(2, palette["text_muted"]),
            border_radius=6,
            alignment=ft.Alignment.CENTER,
        )
        label_text = ft.Text(label, color=palette["text"], size=14, max_lines=None, expand=True)

        def toggle(e=None):
            st["value"] = not st["value"]
            box_visual.content = ft.Icon(ft.Icons.CHECK, color="#FFFFFF" if st["value"] else "transparent", size=16)
            box_visual.bgcolor = palette["accent"] if st["value"] else "transparent"
            box_visual.border = None if st["value"] else ft.Border.all(2, palette["text_muted"])
            try: box_visual.update()
            except Exception: page.update()
            on_change(st["value"])

        return ft.Container(
            content=ft.Row(controls=[box_visual, ft.Container(width=12), label_text], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.Padding.only(left=4, top=10, right=4, bottom=10),
            on_click=toggle,
            ink=True,
        )

    def make_status_row(label, ok: bool, on_action):
        status_icon = ft.Icon(
            ft.Icons.CHECK_CIRCLE if ok else ft.Icons.ERROR_OUTLINE,
            color=palette["success"] if ok else palette["danger"],
            size=20,
        )
        action_btn = None
        if not ok:
            action_btn = ft.Container(
                content=ft.Text("Разрешить", color="#FFFFFF", size=12, weight=ft.FontWeight.W_600),
                padding=ft.Padding.only(left=12, top=6, right=12, bottom=6),
                bgcolor=palette["accent"],
                border_radius=10,
                on_click=lambda e: on_action(),
                ink=True,
            )
        row_controls = [
            status_icon,
            ft.Container(width=10),
            ft.Text(label, color=palette["text"], size=14, expand=True),
        ]
        if action_btn is not None:
            row_controls.append(action_btn)
        return ft.Container(
            content=ft.Row(controls=row_controls, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.Padding.only(left=12, top=12, right=12, bottom=12),
            bgcolor=palette["surface2"],
            border_radius=12,
            margin=ft.Margin.only(bottom=8),
        )

    # ============================================================
    #  Разрешения
    # ============================================================
    perms_holder = ft.Column(spacing=0)

    def rebuild_perms():
        perms_holder.controls.clear()
        perms_holder.controls.append(make_status_row("Точные будильники", perm_state["exact"], on_exact_action))
        perms_holder.controls.append(make_status_row("Работа в фоне (батарея)", perm_state["battery"], on_battery_action))
        perms_holder.controls.append(make_status_row("Уведомления приложения", perm_state["notif"], on_notif_action))
        perms_holder.controls.append(make_status_row("Полноэкранные уведомления", perm_state["full_screen"], on_full_screen_action))
        try: perms_holder.update()
        except Exception: page.update()

    def on_exact_action():
        try: request_exact_alarm_permission()
        except Exception: pass

    def on_battery_action():
        try: request_ignore_battery_optimizations()
        except Exception: pass

    def on_notif_action():
        _open_notification_settings(page)

    def on_full_screen_action():
        _open_full_screen_settings(page)

    def refresh_perms(e=None):
        perm_state["exact"] = has_exact_alarm_permission()
        perm_state["battery"] = is_ignoring_battery_optimizations()
        perm_state["notif"] = _check_notifications_enabled()
        perm_state["full_screen"] = _check_full_screen_intent()
        rebuild_perms()

    # ============================================================
    #  Поведение
    # ============================================================
    def on_confirm_change(val):
        state["confirm_checkbox"] = val
        _set_bool(repo, KEY_CONFIRM_CHECKBOX, val)

    def on_categories_enabled_change(val):
        state["categories_enabled"] = val
        _set_bool(repo, KEY_CATEGORIES_ENABLED, val)

    def on_sync_toggle(val):
        state["sync_enabled"] = val
        _set_bool(repo, KEY_SYNC_ENABLED, val)
        interval_holder.visible = val
        try: interval_holder.update()
        except Exception: page.update()

    interval_field = styled_field("Интервал, сек", palette)
    interval_field.value = state["sync_interval"]
    interval_field.keyboard_type = ft.KeyboardType.NUMBER
    interval_field.width = 140

    interval_chips_row = ft.Row(spacing=6, wrap=True)

    def build_interval_chips():
        interval_chips_row.controls.clear()
        for preset in ("60", "180", "300"):
            selected = (state["sync_interval"] == preset)
            interval_chips_row.controls.append(
                ft.Container(
                    content=ft.Text(f"{preset} с", size=12, weight=ft.FontWeight.W_500, color="#FFFFFF" if selected else palette["text"]),
                    padding=ft.Padding.only(left=10, top=6, right=10, bottom=6),
                    border_radius=14,
                    bgcolor=palette["accent"] if selected else palette["surface2"],
                    on_click=lambda e, p=preset: set_interval(p),
                    ink=True,
                )
            )

    def set_interval(value_str: str):
        state["sync_interval"] = value_str
        interval_field.value = value_str
        build_interval_chips()
        try:
            interval_field.update()
            interval_chips_row.update()
        except Exception:
            page.update()
        repo.set_setting(KEY_SYNC_INTERVAL, value_str)

    def on_interval_field_change(e):
        try:
            v = int((interval_field.value or "180").strip() or "180")
            if v < 30: v = 30
            state["sync_interval"] = str(v)
            repo.set_setting(KEY_SYNC_INTERVAL, str(v))
            build_interval_chips()
            try: interval_chips_row.update()
            except Exception: page.update()
        except Exception:
            pass

    interval_field.on_change = on_interval_field_change
    build_interval_chips()

    interval_holder = ft.Container(
        content=ft.Column(
            controls=[
                ft.Container(height=4),
                ft.Text("Интервал:", color=palette["text_muted"], size=12),
                ft.Container(height=6),
                interval_chips_row,
                ft.Container(height=10),
                interval_field,
                ft.Container(height=8),
            ],
            spacing=0,
        ),
        padding=ft.Padding.only(left=20, right=4),
        visible=(state["sync_enabled"] and not DISTRIBUTION_MODE),
    )

    def on_copy_change(val):
        state["copy_reminder"] = val
        _set_bool(repo, KEY_COPY_REMINDER, val)

    def _build_sync_section():
        if DISTRIBUTION_MODE:
            return ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Icon(ft.Icons.LOCK_OUTLINE, size=20, color=palette["text_muted"]),
                        ft.Container(width=12),
                        ft.Column(
                            controls=[
                                ft.Text("Автосинхронизация", color=palette["text_muted"], size=14),
                                ft.Text("Отключена в этой версии. Синхронизируйте вручную кнопкой 🔄.", color=palette["text_muted"], size=11, max_lines=2),
                            ],
                            spacing=2, expand=True,
                        ),
                    ],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
                padding=ft.Padding.only(left=4, top=10, right=4, bottom=10),
            )
        else:
            return make_toggle("Автосинхронизация", state["sync_enabled"], on_sync_toggle)

    def on_at_time_change(val):
        state["at_time_default"] = val
        _set_bool(repo, KEY_AT_TIME_DEFAULT, val)

    # ============================================================
    #  Действия
    # ============================================================
    def do_logout(e):
        if on_logout:
            try: on_logout()
            except Exception as ex: print(f"[settings] on_logout error: {ex}")

    def _show_soon(text):
        page.snack_bar = ft.SnackBar(content=ft.Text(text, color="#FFFFFF"), bgcolor=palette["surface3"])
        page.snack_bar.open = True
        page.update()

    def do_cleanup(e):
        from views.cleanup_view import open_cleanup_overlay
        open_cleanup_overlay(page, palette, repo)

    def _confirm_change_password():
        email = (session.email if session and session.email else "").strip()
        if not email:
            _show_soon("Не удалось определить email")
            return

        def do_yes(ev):
            page.pop_dialog()
            _send_reset(email)

        def do_no(ev):
            page.pop_dialog()

        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Сменить пароль?", color=palette["text"], size=16),
            content=ft.Text(f"На {email} придёт письмо со ссылкой для сброса пароля.", color=palette["text"], size=13),
            actions=[
                ft.Row(
                    controls=[
                        ft.Container(content=ft.Text("Отправить", color="#FFFFFF", size=14, weight=ft.FontWeight.W_600), padding=10, bgcolor=palette["accent"], border_radius=12, on_click=do_yes, ink=True, expand=True, alignment=ft.Alignment.CENTER),
                        ft.Container(width=10),
                        ft.Container(content=ft.Text("Отмена", color=palette["text"], size=14, weight=ft.FontWeight.W_600), padding=10, bgcolor=palette["surface2"], border_radius=12, on_click=do_no, ink=True, expand=True, alignment=ft.Alignment.CENTER),
                    ],
                    spacing=0,
                ),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        page.show_dialog(dlg)

    def _show_result_dialog(ok: bool, msg: str):
        def close(ev): page.pop_dialog()
        dlg = ft.AlertDialog(
            modal=True,
            bgcolor=palette["surface"],
            title=ft.Text("Готово" if ok else "Ошибка", color=palette["success"] if ok else palette["danger"], size=16),
            content=ft.Text(msg, color=palette["text"], size=13),
            actions=[ft.Container(content=ft.Text("OK", color="#FFFFFF", size=14, weight=ft.FontWeight.W_600), padding=ft.Padding.only(left=24, top=10, right=24, bottom=10), bgcolor=palette["accent"], border_radius=12, on_click=close, ink=True, alignment=ft.Alignment.CENTER)],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        page.show_dialog(dlg)

    def _send_reset(email: str):
        page.snack_bar = ft.SnackBar(content=ft.Text("Отправляем письмо...", color="#FFFFFF"), bgcolor=palette["surface3"], duration=2000)
        page.snack_bar.open = True
        page.update()

        async def _do_send():
            ok = False
            msg = ""
            try:
                from cloud.firebase_auth import send_password_reset
                from pycompat import run_io
                await run_io(send_password_reset, email)
                ok = True
                msg = f"Письмо со ссылкой отправлено на {email}"
            except Exception as ex:
                msg = getattr(ex, "message", str(ex))
            try: _show_result_dialog(ok, msg)
            except Exception: pass

        try: page.run_task(_do_send)
        except Exception: pass

    def do_change_password(e):
        _confirm_change_password()

    # ============================================================
    #  Контент
    # ============================================================
    def build_font_chips():
        def make_chip(label, value):
            selected = (state["font_scale"] == value)
            return ft.Container(
                content=ft.Text(label, size=12, weight=ft.FontWeight.W_500, color="#FFFFFF" if selected else palette["text"]),
                padding=ft.Padding.only(left=12, top=8, right=12, bottom=8),
                border_radius=14,
                bgcolor=palette["accent"] if selected else palette["surface2"],
                on_click=lambda e, v=value: set_font_scale(v),
                ink=True,
            )

        def set_font_scale(val):
            state["font_scale"] = val
            repo.set_setting(KEY_FONT_SCALE, val)
            new_row = build_font_chips()
            font_row_holder.content = new_row
            try: font_row_holder.update()
            except Exception: page.update()

        return ft.Row(controls=[make_chip("Стандарт", "1.0"), make_chip("Крупный", "1.15"), make_chip("Очень крупный", "1.3")], spacing=6, wrap=True)

    font_row_holder = ft.Container(content=build_font_chips())

    ICON_OPTIONS = [
        ("time", "Время исполнения"), ("priority", "Приоритет (звёзды)"), ("note", "Примечание (📝)"),
        ("repeat", "Повторение (🔁)"), ("subtasks", "Подзадачи (📋)"), ("reminder", "Напоминание (🔔)"),
    ]

    def make_icon_toggle(icon_id, label):
        is_on = icon_id in state["visible_icons"]
        def on_toggle(enabled):
            if enabled: state["visible_icons"].add(icon_id)
            else: state["visible_icons"].discard(icon_id)
            repo.set_setting(KEY_VISIBLE_ICONS, ",".join(state["visible_icons"]))
        return make_toggle(label, is_on, on_toggle)

    # ============ iPhone / PWA ============
    TZ_OPTIONS = [
        ("", "Как на сервере (по умолчанию)"),
        ("Europe/Moscow", "Europe/Moscow — Москва"),
        ("Europe/Kaliningrad", "Europe/Kaliningrad"),
        ("Europe/Samara", "Europe/Samara"),
        ("Asia/Yekaterinburg", "Asia/Yekaterinburg"),
        ("Asia/Novosibirsk", "Asia/Novosibirsk"),
        ("Asia/Krasnoyarsk", "Asia/Krasnoyarsk"),
        ("Asia/Irkutsk", "Asia/Irkutsk"),
        ("Asia/Vladivostok", "Asia/Vladivostok"),
        ("UTC", "UTC"),
    ]

    async def do_open_push_setup(e):
        """Открывает страницу включения системных уведомлений (Web Push)."""
        uid = (session.uid or "") if session else ""
        url = "/push-setup.html" + (f"?uid={uid}" if uid else "")
        try:
            await page.launch_url(url, web_popup_window_name=ft.UrlTarget.BLANK)
        except Exception as ex:
            _show_soon(f"Не удалось открыть страницу: {ex}")

    def on_tz_change(e):
        val = (e.control.value or "").strip()
        try:
            # пишем и в персональный ключ (общий сервер — у каждого свой пояс),
            # и в старый глобальный (совместимость со старыми версиями)
            repo.set_setting("user_timezone", val)
            uid = session.uid if session else None
            if uid:
                repo.set_setting(f"user_timezone:{uid}", val)
            _show_soon("Часовой пояс сохранён: " + (val or "как на сервере"))
        except Exception as ex:
            _show_soon(f"Ошибка сохранения: {ex}")

    tz_dropdown = ft.Dropdown(
        value=(repo.get_setting(f"user_timezone:{session.uid}", "") or "")
        if (session and session.uid) else (repo.get_setting("user_timezone", "") or ""),
        options=[ft.dropdown.Option(key=kv[0], text=kv[1]) for kv in TZ_OPTIONS],
        on_select=on_tz_change,
        text_size=13,
        content_padding=ft.Padding.only(left=12, top=10, right=12, bottom=10),
        border_color=palette["border"],
        bgcolor=palette["surface2"],
        focused_border_color=palette["accent"],
        expand=True,
    )

    def do_refresh_reminders(e):
        try:
            n = repo.refresh_reminders_tz()
            _show_soon(f"Пересчитано напоминаний: {n}" if n
                       else "Нет активных напоминаний для пересчёта")
        except Exception as ex:
            _show_soon(f"Ошибка пересчёта: {ex}")

    content = ft.Column(
        controls=[
            section_title("Разрешения"),
            ft.Row(controls=[ft.Text("Статусы системных разрешений", color=palette["text"], size=14, expand=True), ft.Container(content=ft.Row(controls=[ft.Icon(ft.Icons.REFRESH, size=16, color=palette["accent"]), ft.Text("Обновить", color=palette["accent"], size=12)], spacing=4, tight=True), padding=ft.Padding.only(left=10, top=6, right=10, bottom=6), bgcolor=palette["surface3"], border_radius=10, on_click=refresh_perms, ink=True)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=8),
            perms_holder,

            section_title("Поведение"),
            make_toggle("Спрашивать перед отметкой выполненной", state["confirm_checkbox"], on_confirm_change),
            _build_sync_section(),
            interval_holder,
            make_toggle("Копировать напоминание в повторяющихся задачах", state["copy_reminder"], on_copy_change),
            make_toggle("Переносить невыполненные разовые задачи на сегодня", 
                        state["carry_over_singles"], 
                        lambda v: (_set_bool(repo, KEY_CARRY_OVER_SINGLES, v), state.update({"carry_over_singles": v}))),

            section_title("Категории"),
            make_toggle("Включить работу с категориями — Личные, Работа, Прочие", state["categories_enabled"], on_categories_enabled_change),

            section_title("Внешний вид"),
            ft.Row(controls=[ft.Text("Размер шрифта", color=palette["text"], size=14, expand=True)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=6),
            font_row_holder,
            ft.Container(height=6),

            section_title("Значки в задачах"),
            ft.Text("Выберите, какую информацию показывать под названием:", color=palette["text_muted"], size=12),
            ft.Container(height=6),
            *(make_icon_toggle(icon_id, label) for icon_id, label in ICON_OPTIONS),            

            section_title("Напоминания"),
            make_toggle("По умолчанию напоминать в момент события", state["at_time_default"], on_at_time_change),

            section_title("iPhone / PWA"),
            ft.Text("Установка на iPhone через Safari — без App Store и iCloud.", color=palette["text_muted"], size=12),
            ft.Container(height=6),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.NOTIFICATIONS_ACTIVE, size=20, color=palette["accent"]), ft.Container(width=10), ft.Text("Системные уведомления (Web Push)", color=palette["text"], size=14, expand=True), ft.Icon(ft.Icons.OPEN_IN_NEW, size=14, color=palette["text_muted"])], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=14, right=12, bottom=14), bgcolor=palette["surface2"], border_radius=12, on_click=do_open_push_setup, ink=True, margin=ft.Margin.only(bottom=8),
            ),
            ft.Row(controls=[ft.Text("Часовой пояс напоминаний", color=palette["text"], size=14)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ft.Container(height=6),
            tz_dropdown,
            ft.Container(height=6),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.UPDATE, size=20, color=palette["accent"]), ft.Container(width=10), ft.Text("Пересчитать напоминания под этот пояс", color=palette["text"], size=14, expand=True)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=14, right=12, bottom=14), bgcolor=palette["surface2"], border_radius=12, on_click=do_refresh_reminders, ink=True, margin=ft.Margin.only(bottom=8),
            ),

            section_title("Данные"),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.DELETE_SWEEP, size=20, color=palette["danger"]), ft.Container(width=10), ft.Text("Очистка данных", color=palette["text"], size=14, expand=True), ft.Icon(ft.Icons.ARROW_FORWARD_IOS, size=14, color=palette["text_muted"])], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=14, right=12, bottom=14), bgcolor=palette["surface2"], border_radius=12, on_click=do_cleanup, ink=True, margin=ft.Margin.only(bottom=8),
            ),

            section_title("Аккаунт"),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.PERSON, size=20, color=palette["text_muted"]), ft.Container(width=10), ft.Text(session.email if session and session.email else "—", color=palette["text"], size=13, expand=True)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=12, right=12, bottom=12), bgcolor=palette["surface2"], border_radius=12, margin=ft.Margin.only(bottom=8),
            ),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.LOCK_RESET, size=20, color=palette["text_muted"]), ft.Container(width=10), ft.Text("Сменить пароль", color=palette["text"], size=14, expand=True), ft.Icon(ft.Icons.ARROW_FORWARD_IOS, size=14, color=palette["text_muted"])], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=14, right=12, bottom=14), bgcolor=palette["surface2"], border_radius=12, on_click=do_change_password, ink=True, margin=ft.Margin.only(bottom=8),
            ),
            ft.Container(
                content=ft.Row(controls=[ft.Icon(ft.Icons.LOGOUT, size=20, color=palette["danger"]), ft.Container(width=10), ft.Text("Выйти из аккаунта", color=palette["danger"], size=14, expand=True)], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.Padding.only(left=12, top=14, right=12, bottom=14), bgcolor=palette["surface2"], border_radius=12, on_click=do_logout, ink=True, margin=ft.Margin.only(bottom=8),
            ),

            section_title("О приложении"),
            ft.Container(
                content=ft.Column(controls=[ft.Text("Ежедневник", color=palette["text"], size=14, weight=ft.FontWeight.W_500), ft.Text("Версия 0.1.0", color=palette["text_muted"], size=12), ft.Text("Разработано: Свобода выбора", color=palette["text_muted"], size=12)], spacing=4),
                padding=ft.Padding.only(left=12, top=12, right=12, bottom=12), bgcolor=palette["surface2"], border_radius=12,
            ),
            ft.Container(height=30),
        ],
        spacing=0,
        scroll=ft.ScrollMode.AUTO,
        horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
    )

    body = ft.Container(
        content=content,
        padding=ft.Padding.only(left=16, top=10, right=16, bottom=20),
        expand=True,
    )

    view = ft.View(
        route="/settings",
        appbar=ft.AppBar(
            leading=ft.IconButton(ft.Icons.ARROW_BACK, icon_color=palette["text"], on_click=_on_back),
            title=ft.Text("Настройки", color=palette["text"], size=18, weight=ft.FontWeight.W_600),
            bgcolor=palette["surface"],
            center_title=False,
        ),
        controls=[
            ft.SafeArea(
                content=body,
                expand=True
            )
        ],
        padding=0,
        spacing=0,
        bgcolor=palette["bg"],
    )

    rebuild_perms()
    return view