/* flutter_service_worker.js — service worker «Ежедневника» (scope '/').
 *
 * ЗАТЕНЯЕТ одноимённый файл из flet_web (assets/ имеет приоритет).
 * Зачем: flutter-bootstrap сам регистрирует SW на scope '/', если видит
 * любую существующую регистрацию, и затирает чужую. Поэтому мы отдаём СВОЙ
 * файл под его именем — тогда и наша регистрация, и штатная регистрация
 * flet приводят к одному и тому же воркеру.
 *
 * Что делает:
 *  - офлайн-навигации (открытие/перезагрузка страницы без сети) показывает
 *    offline.html вместо белого экрана/ошибки Safari;
 *  - ВСЁ остальное пропускает насквозь: страница, /ws, /api/*, canvaskit —
 *    никогда не кэшируются (Flet работает в сервер-режиме, кэш ломал бы
 *    обновления и хендшейк сессии).
 *
 * Push-уведомления обслуживает отдельный воркер /sw.js (scope '/push/').
 */
const OFFLINE_URL = '/offline.html';
const CACHE = 'ezh-offline-v1';

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.add(OFFLINE_URL))
  );
  // Обновления (flet регистрирует тот же файл с другим ?v=) вступают сразу:
  // содержимое идентично, ждать закрытия вкладок нечего.
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim()) // контролировать страницы сразу
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.mode !== 'navigate') return; // всё, кроме переходов страниц — насквозь
  // cache:'reload' — только сеть, HTTP-кэш не используем: иначе браузер в
  // офлайне отдаёт index.html из кэша и пользователь видит «вечную загрузку»
  // вместо офлайн-страницы. Сбой сети -> offline.html (с автоповтором).
  event.respondWith(
    fetch(req, { cache: 'reload' }).catch(() =>
      caches.match(OFFLINE_URL, { ignoreSearch: true })
    )
  );
});
