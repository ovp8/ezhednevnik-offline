# sync/network_cache.py
"""Проверка доступности сети перед синком.

ВАЖНО для Pyodide (статическая сборка):
  requests.head() в браузере НЕ работает — CORS блокирует ответ HEAD,
  а pyodide_http бросает pyodide.ffi.JsException, который НЕ наследуется
  от requests.RequestException. Из-за этого прежняя проверка валила
  весь sync с необработанным исключением (кнопка 🔄 молча «крутилась»).
  Все реальные запросы синка (POST/PATCH/GET на firestore.googleapis.com)
  в браузере работают — это проверено прямым пробником.

  Поэтому в Pyodide сеть проверяем через navigator.onLine (мгновенно),
  а если сеть реально пропала — sync получит ошибку в самом запросе
  (push_failed / pull error), что честнее ложной блокировки.
"""
import sys
import time

IS_PYODIDE = sys.platform == "emscripten"

_last_network_check = 0
_last_network_result = True
NETWORK_CACHE_TTL = 10  # секунд

PROBE_URL = "https://firestore.googleapis.com/"
PROBE_TIMEOUT = 3


def _real_check() -> bool:
    if IS_PYODIDE:
        try:
            import js  # pyodide: глобальный scope воркера
            return bool(js.navigator.onLine)
        except Exception:
            # Не смогли спросить браузер — не блокируем sync.
            return True
    try:
        import requests
        # 404/403/200 — не важно, главное что TCP+TLS установились.
        # except Exception (а не только RequestException): шим pyodide_http
        # бросает JsException, не входящий в иерархию requests.
        requests.head(PROBE_URL, timeout=PROBE_TIMEOUT)
        return True
    except Exception:
        return False


def cached_network_available() -> bool:
    global _last_network_check, _last_network_result
    now = time.time()
    if now - _last_network_check > NETWORK_CACHE_TTL:
        _last_network_result = _real_check()
        _last_network_check = now
    return _last_network_result


def invalidate_network_cache():
    global _last_network_check
    _last_network_check = 0
