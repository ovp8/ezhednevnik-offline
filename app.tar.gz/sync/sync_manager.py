# sync/sync_manager.py
"""
Синхронизация локальной SQLite с Firestore.

Стратегия:
  * Push (всегда): pending_create / pending_update / pending_delete.
  * Pull (по запросу): полный (при первом входе) или delta
    (только документы с updatedAt > last_pull_ts).
  * LWW по полю updated_at (ISO 8601, строковое сравнение).
  * Soft-delete: удаления помечаются флагом deleted=true и синхронизируются как обычные изменения.
  * Cooldown при 429 — чтобы при исчерпании квоты Firebase приложение не спамило.
"""
import time
from typing import Optional, Any
from db.local_db import LocalDB, CATEGORY_DEFAULT
from cloud.firestore_client import FirestoreClient, FirestoreError
from sync.network_cache import cached_network_available


COLLECTION = "tasks"
MAX_RETRIES = 5


# ---------- Cooldown для 429 ----------

_COOLDOWN_UNTIL = 0.0
_COOLDOWN_SECONDS = 300  # 5 минут


def _is_cooldown_active() -> bool:
    return time.time() < _COOLDOWN_UNTIL


def _set_cooldown(seconds: int = _COOLDOWN_SECONDS):
    global _COOLDOWN_UNTIL
    _COOLDOWN_UNTIL = time.time() + seconds
    print(f"[sync] cooldown set until {_COOLDOWN_UNTIL} (+{seconds}s)")


def _is_quota_error(exc: Exception) -> bool:
    s = str(exc)
    return "429" in s or "RESOURCE_EXHAUSTED" in s or "Quota exceeded" in s


class SyncResult:
    def __init__(self):
        self.pushed = 0
        self.pulled_new = 0
        self.pulled_updated = 0
        self.pulled_deleted = 0
        self.failed = 0
        self.skipped_no_network = False
        self.skipped_cooldown = False

    def __repr__(self):
        return (f"SyncResult(pushed={self.pushed}, "
                f"pulled_new={self.pulled_new}, "
                f"pulled_updated={self.pulled_updated}, "
                f"pulled_deleted={self.pulled_deleted}, "
                f"failed={self.failed}, "
                f"no_network={self.skipped_no_network}, "
                f"cooldown={self.skipped_cooldown})")


# ---------------- Push ----------------

def push_pending(db: LocalDB, fs: FirestoreClient, user_id: str) -> tuple:
    pending = db.get_unsynced_tasks()
    success = 0
    failed = 0

    for task in pending:
        try:
            _push_one(db, fs, user_id, task)
            success += 1
        except FirestoreError as e:
            failed += 1
            print(f"[sync] push failed for id={task['id']}: {e}")
            if _is_quota_error(e):
                # Quota exhausted - activate cooldown and stop pushing,
                # otherwise we keep spamming Firebase and prolong the block.
                _set_cooldown()
                break
        except Exception as e:
            failed += 1
            print(f"[sync] push unexpected error id={task['id']}: {e}")

    return success, failed


def _push_one(db: LocalDB, fs: FirestoreClient, user_id: str, task: dict):
    status = task["sync_status"]

    # ----- Soft-delete -----
    if status == "pending_delete":
        if task.get("cloud_id"):
            try:
                fs.soft_delete(COLLECTION, task["cloud_id"], user_id)
            except Exception as e:
                print(f"[sync] soft_delete failed for id={task['id']}: {e}")
                raise
        db.mark_task_remotely_deleted(task["id"])
        return

    # Локальное время правки (мс) — основа LWW
    local_updated_ms = _millis_from_iso(task.get("updated_at"))

    payload = {
        "userId": user_id,
        "task": task["task"],
        "priority": task["priority"],
        "datetime": task["datetime"] or "",
        "status": task["status"],
        "details": task["details"] if isinstance(task["details"], list) else [],
        "repeat": task["repeat"] if task["repeat"] is not None else None,
        "note": task["note"] or "",
        "category": task.get("category") or CATEGORY_DEFAULT,
        "updatedAt": local_updated_ms,
        "deleted": False,   # явно снимаем флаг при обновлении
    }

    # ---------- CREATE ----------
    if status == "pending_create":
        created = fs.create_document(COLLECTION, payload)
        db.mark_task_synced(task["id"], cloud_id=created["_id"])
        return

    # ---------- UPDATE ----------
    if status == "pending_update":
        cloud_id = task.get("cloud_id")
        if not cloud_id:
            # Локально pending_update без cloud_id → создаём
            created = fs.create_document(COLLECTION, payload)
            db.mark_task_synced(task["id"], cloud_id=created["_id"])
            return

        # Проверка LWW: если облако новее — применяем его, свой push отменяем
        try:
            remote = fs.get_document(COLLECTION, cloud_id)
            remote_updated_ms = int(remote.get("updatedAt") or 0)
        except FirestoreError:
            remote_updated_ms = 0

        if remote_updated_ms > local_updated_ms:
            db.apply_remote_update(task["id"], {
                "task": remote.get("task", ""),
                "priority": remote.get("priority", 3),
                "datetime": remote.get("datetime", ""),
                "status": remote.get("status", 0),
                "details": remote.get("details", []),
                "repeat": remote.get("repeat"),
                "note": remote.get("note"),
                "category": remote.get("category", CATEGORY_DEFAULT),
                "updated_at": _iso_from_millis(remote_updated_ms),
                "cloud_updated_at": _iso_from_millis(remote_updated_ms),
            })
            return

        fs.set_document(COLLECTION, cloud_id, payload)
        db.mark_task_synced(task["id"], cloud_id=cloud_id)


# ---------------- Pull ----------------

def pull_remote(db: Any, fs: FirestoreClient, user_id: str,
                since_ts: int = 0, full: bool = False) -> tuple:
    """
    Pull из Firestore.

    since_ts: если > 0, читаем только документы с updatedAt > since_ts
    full:     если True, выполняется полный pull (со сверкой удалений).
              При full=False удаления НЕ обрабатываются напрямую —
              вместо этого soft-deleted документы приходят в delta.

    Возвращает (new_count, updated_count, deleted_count, max_updated_at)
    """
    if full or since_ts <= 0:
        filters = [("userId", user_id)]
    else:
        filters = [
            ("userId", user_id),
            ("updatedAt", "GREATER_THAN", since_ts),
        ]
    order_by = [("updatedAt", "ASCENDING")]

    remote_docs = fs.query(COLLECTION, filters, order_by=order_by, limit=500)
    print(f"[pull] user={user_id}, since={since_ts}, full={full}, "
          f"got {len(remote_docs)} docs")

    remote_by_cloud_id = {doc["_id"]: doc for doc in remote_docs}

    new_count = 0
    updated_count = 0
    deleted_count = 0
    max_updated = since_ts

    for cloud_id, remote in remote_by_cloud_id.items():
        r_updated = int(remote.get("updatedAt") or 0)
        if r_updated > max_updated:
            max_updated = r_updated

        local = db.find_by_cloud_id(cloud_id)

        # ---- Soft-delete: документ помечен удалённым ----
        if remote.get("deleted"):
            if local:
                db.mark_task_remotely_deleted(local["id"])
                deleted_count += 1
            continue

        # ---- Новый документ ----
        if local is None:
            db.insert_remote_task({
                "cloud_id": cloud_id,
                "user_id": remote.get("userId"),
                "task": remote.get("task", ""),
                "priority": remote.get("priority", 3),
                "datetime": remote.get("datetime", ""),
                "status": remote.get("status", 0),
                "details": remote.get("details", []),
                "repeat": remote.get("repeat"),
                "note": remote.get("note"),
                "category": remote.get("category", CATEGORY_DEFAULT),
                "updated_at": _iso_from_millis(r_updated),
                "cloud_updated_at": _iso_from_millis(r_updated),
            })
            new_count += 1
            continue

        # ---- Существующий документ: сравнение по LWW ----
        local_updated_ms = _millis_from_iso(local.get("updated_at"))

        if local["sync_status"] != "synced":
            if local_updated_ms > r_updated:
                continue  # локальная новее — push отправит

        if r_updated > local_updated_ms:
            db.apply_remote_update(local["id"], {
                "task": remote.get("task", ""),
                "priority": remote.get("priority", 3),
                "datetime": remote.get("datetime", ""),
                "status": remote.get("status", 0),
                "details": remote.get("details", []),
                "repeat": remote.get("repeat"),
                "note": remote.get("note"),
                "category": remote.get("category", CATEGORY_DEFAULT),
                "updated_at": _iso_from_millis(r_updated),
                "cloud_updated_at": _iso_from_millis(r_updated),
            })
            updated_count += 1

    # При полном pull — досверка: у нас есть cloud_id, в облаке его нет.
    # Это может быть удаление, произошедшее другим устройством.
    # Но в soft-delete схеме мы вместо этого просто полагаемся на флаг `deleted`.
    # На всякий случай оставим эту ветку — на случай, если документ был
    # физически удалён из Firestore вручную.
    if full:
        local_with_cloud = [
            t for t in db.get_all_tasks()
            if t.get("cloud_id") and t.get("user_id") == user_id
        ]
        for local in local_with_cloud:
            if local["cloud_id"] not in remote_by_cloud_id:
                if local["sync_status"] == "pending_delete":
                    continue
                db.mark_task_remotely_deleted(local["id"])
                deleted_count += 1

    return new_count, updated_count, deleted_count, max_updated


# ---------------- Полный цикл ----------------

def sync_once(db: Any, fs: FirestoreClient, user_id: str,
              do_pull: bool = True) -> SyncResult:
    result = SyncResult()

    if not cached_network_available():
        result.skipped_no_network = True
        return result

    if _is_cooldown_active():
        result.skipped_cooldown = True
        return result

    # Push — всегда
    try:
        pushed, push_failed = push_pending(db, fs, user_id)
        result.pushed = pushed
        result.failed = push_failed
    except Exception as e:
        print(f"[sync] push phase error: {e}")
        result.failed += 1
        if _is_quota_error(e):
            _set_cooldown()

    # Pull — только когда разрешено
    if do_pull:
        try:
            key = f"last_pull_ts_{user_id}"
            since = int(db.get_setting(key, "0") or 0)
            # При первом pull (since=0) — полный, дальше — delta
            full = (since <= 0)

            new_c, upd_c, del_c, max_ts = pull_remote(
                db, fs, user_id, since_ts=since, full=full
            )
            result.pulled_new = new_c
            result.pulled_updated = upd_c
            result.pulled_deleted = del_c

            if max_ts > since:
                db.set_setting(key, str(max_ts))
                print(f"[pull] saved last_pull_ts={max_ts}")
        except Exception as e:
            print(f"[sync] pull phase error: {e}")
            result.failed += 1
            if _is_quota_error(e):
                _set_cooldown()

    return result


# ---------------- Утилиты времени ----------------

def _iso_from_millis(ms) -> Optional[str]:
    if ms is None:
        return None
    from datetime import datetime, timezone
    try:
        dt = datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)
        return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    except (TypeError, ValueError):
        return None


def _millis_from_iso(iso: Optional[str]) -> int:
    if not iso:
        return 0
    from datetime import datetime, timezone
    try:
        s = iso.rstrip("Z")
        if "." in s:
            dt = datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%f")
        else:
            dt = datetime.strptime(s, "%Y-%m-%dT%H:%M:%S")
        return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)
    except (ValueError, TypeError):
        return 0